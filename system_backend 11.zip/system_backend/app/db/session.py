"""
session.py

SQLAlchemy session and model registration for Smart Gym Management System.
Author: Ndatimana Jean de Dieu
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from app.core.config import settings

# Create SQLAlchemy engine. Set echo=True for debugging SQL output (development only)
engine = create_engine(settings.DATABASE_URL, echo=False)

# Session factory for creating new Session objects
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Declarative base for model classes
Base = declarative_base()

# Import all models so Alembic (migrations) and SQLAlchemy see them
from app.models.user import User
from app.models.gym import Gym
from app.models.gym_membership_plan_template import GymMembershipPlanTemplate
from app.models.member import Member
from app.models.payment import Payment
from app.models.membership import Membership
from app.models.workout_plan import WorkoutPlan
from app.models.nutrition_plan import NutritionPlan
from app.models.attendance import Attendance
from app.models.equipment import Equipment
from app.models.equipment_issue import EquipmentIssue
from app.models.gym_subscription import GymSubscription
