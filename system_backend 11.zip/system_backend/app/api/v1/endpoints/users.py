"""
users.py

Endpoints for CRUD operations on users.
Author: Ndatimana Jean de Dieu
"""

from fastapi import APIRouter, HTTPException, status, Depends
from typing import List, Optional
from pydantic import BaseModel, EmailStr
from app.models.user import UserRole
from app.core.rbac import RoleChecker

users_router = APIRouter(prefix="/users", tags=["Users"])

# --- Pydantic Schemas (replace with import from schemas.user if available) ---
class UserBase(BaseModel):
    email: EmailStr
    full_name: Optional[str] = None
    role: UserRole
    gym_id: Optional[int] = None

class UserCreate(UserBase):
    password: str

class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    full_name: Optional[str] = None
    password: Optional[str] = None
    role: Optional[UserRole] = None
    gym_id: Optional[int] = None

class UserRead(UserBase):
    id: int

    class Config:
        orm_mode = True
        use_enum_values = True

# --- In-memory demo store (replace with DB) ---
_users_db: List[UserRead] = []

# --- CRUD Endpoints ---

@users_router.get("/", response_model=List[UserRead], dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER", "GYM_OWNER", "GYM_MANAGER"]))])
def list_users():
    """Retrieve all users."""
    return _users_db

@users_router.post("/", response_model=UserRead, status_code=status.HTTP_201_CREATED, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER", "GYM_OWNER", "GYM_MANAGER"]))])
def create_user(user: UserCreate):
    """Create a new user."""
    new_id = (_users_db[-1].id + 1) if _users_db else 1
    new_user = UserRead(id=new_id, **user.dict(exclude={"password"}))
    _users_db.append(new_user)
    return new_user

@users_router.get("/{user_id}", response_model=UserRead, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER", "GYM_OWNER", "GYM_MANAGER", "MEMBER", "STAFF", "TRAINER"]))])
def get_user(user_id: int):
    """Get a user by ID."""
    for user in _users_db:
        if user.id == user_id:
            return user
    raise HTTPException(status_code=404, detail="User not found")

@users_router.put("/{user_id}", response_model=UserRead, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER", "GYM_OWNER", "GYM_MANAGER"]))])
def update_user(user_id: int, updates: UserUpdate):
    """Update a user's information."""
    for idx, user in enumerate(_users_db):
        if user.id == user_id:
            updated = user.copy(update=updates.dict(exclude_unset=True))
            _users_db[idx] = updated
            return updated
    raise HTTPException(status_code=404, detail="User not found")

@users_router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER", "GYM_OWNER", "GYM_MANAGER"]))])
def delete_user(user_id: int):
    """Delete a user."""
    global _users_db
    _users_db = [u for u in _users_db if u.id != user_id]
    return
