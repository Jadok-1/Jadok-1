"""
auth.py

Authentication endpoints for Smart Gym Management System.
Author: Ndatimana Jean de Dieu
"""

from fastapi import APIRouter, HTTPException, status, Depends
from pydantic import BaseModel, EmailStr
from typing import Optional
from app.core.security import get_password_hash, verify_password, create_access_token
from app.core.rbac import RoleChecker

auth_router = APIRouter(prefix="/auth", tags=["Auth"])

# Example Pydantic models
class UserRegister(BaseModel):
    email: EmailStr
    password: str
    full_name: Optional[str] = None

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str

# In-memory user store for demo purposes (replace with DB logic)
_fake_users = {}

@auth_router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
def register(user: UserRegister):
    """
    Register a new user (member, staff, etc.).
    """
    if user.email in _fake_users:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )
    hashed_pw = get_password_hash(user.password)
    _fake_users[user.email] = {
        "email": user.email,
        "hashed_password": hashed_pw,
        "full_name": user.full_name,
        "role": "MEMBER",  # Default role; adjust as needed
    }
    access_token = create_access_token({"sub": user.email, "role": "MEMBER"})
    return {"access_token": access_token, "token_type": "bearer"}

@auth_router.post("/login", response_model=TokenResponse)
def login(user: UserLogin):
    """
    Authenticate user and issue JWT access token.
    """
    account = _fake_users.get(user.email)
    if not account or not verify_password(user.password, account["hashed_password"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials"
        )
    access_token = create_access_token({"sub": user.email, "role": account["role"]})
    return {"access_token": access_token, "token_type": "bearer"}

@auth_router.get("/me", dependencies=[Depends(RoleChecker(["MEMBER", "STAFF", "TRAINER", "GYM_OWNER", "SYSTEM_MANAGER"]))])
def get_current_user_info(email: EmailStr):
    """
    Get profile info for the current logged-in user.
    """
    user = _fake_users.get(email)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@auth_router.get("/test", summary="Test auth router")
def test_auth():
    """A simple test endpoint to confirm the router is working."""
    return {"msg": "Auth router is working!"}
