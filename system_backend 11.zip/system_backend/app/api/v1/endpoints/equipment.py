"""
equipment.py

Endpoints for CRUD operations on gym equipment.
Author: Ndatimana Jean de Dieu
"""

from fastapi import APIRouter, HTTPException, status, Depends
from typing import List, Optional
from pydantic import BaseModel
from app.models.equipment import EquipmentStatus  # Import your Enum
from app.core.rbac import RoleChecker

equipment_router = APIRouter(prefix="/equipment", tags=["Equipment"])

# --- Pydantic Schemas (replace with import from schemas.equipment if available) ---
class EquipmentBase(BaseModel):
    name: str
    description: Optional[str] = None
    status: EquipmentStatus

class EquipmentCreate(EquipmentBase):
    pass

class EquipmentUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[EquipmentStatus] = None

class EquipmentRead(EquipmentBase):
    id: int
    gym_id: int

    class Config:
        orm_mode = True
        use_enum_values = True

# --- In-memory demo store (replace with DB) ---
_equipment_db: List[EquipmentRead] = []

# --- CRUD Endpoints ---

@equipment_router.get("/", response_model=List[EquipmentRead], dependencies=[Depends(RoleChecker(["GYM_MANAGER", "CASHIER", "STAFF", "TRAINER"]))])
def list_equipment():
    """Retrieve all gym equipment."""
    return _equipment_db

@equipment_router.post("/", response_model=EquipmentRead, status_code=status.HTTP_201_CREATED, dependencies=[Depends(RoleChecker(["GYM_MANAGER", "CASHIER"]))])
def create_equipment(item: EquipmentCreate):
    """Add new equipment to gym."""
    new_id = (_equipment_db[-1].id + 1) if _equipment_db else 1
    gym_id = 1  # Placeholder; replace with context/gym from token
    new_equipment = EquipmentRead(id=new_id, gym_id=gym_id, **item.dict())
    _equipment_db.append(new_equipment)
    return new_equipment

@equipment_router.get("/{equipment_id}", response_model=EquipmentRead, dependencies=[Depends(RoleChecker(["GYM_MANAGER", "CASHIER", "STAFF", "TRAINER"]))])
def get_equipment(equipment_id: int):
    """Get gym equipment by ID."""
    for item in _equipment_db:
        if item.id == equipment_id:
            return item
    raise HTTPException(status_code=404, detail="Equipment not found")

@equipment_router.put("/{equipment_id}", response_model=EquipmentRead, dependencies=[Depends(RoleChecker(["GYM_MANAGER", "CASHIER"]))])
def update_equipment(equipment_id: int, updates: EquipmentUpdate):
    """Update equipment details."""
    for idx, item in enumerate(_equipment_db):
        if item.id == equipment_id:
            updated = item.copy(update=updates.dict(exclude_unset=True))
            _equipment_db[idx] = updated
            return updated
    raise HTTPException(status_code=404, detail="Equipment not found")

@equipment_router.delete("/{equipment_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(RoleChecker(["GYM_MANAGER", "CASHIER"]))])
def delete_equipment(equipment_id: int):
    """Delete equipment from gym."""
    global _equipment_db
    _equipment_db = [e for e in _equipment_db if e.id != equipment_id]
    return
