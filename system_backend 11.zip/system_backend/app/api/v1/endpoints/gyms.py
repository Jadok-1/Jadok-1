"""
gyms.py

Endpoints for CRUD operations on gyms.
Author: Ndatimana Jean de Dieu
"""

from fastapi import APIRouter, HTTPException, status, Depends
from typing import List
from pydantic import BaseModel
from app.core.rbac import RoleChecker

gyms_router = APIRouter(prefix="/gyms", tags=["Gyms"])

# --- Pydantic Schemas (replace with import from schemas.gym if available) ---
class GymBase(BaseModel):
    name: str

class GymCreate(GymBase):
    pass

class GymUpdate(BaseModel):
    name: str

class GymRead(GymBase):
    id: int

    class Config:
        orm_mode = True

# --- In-memory demo store (replace with DB) ---
_gyms_db: List[GymRead] = []

# --- CRUD Endpoints ---

@gyms_router.get("/", response_model=List[GymRead], dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER", "GYM_OWNER", "GYM_MANAGER", "CASHIER"]))])
def list_gyms():
    """Retrieve all gyms."""
    return _gyms_db

@gyms_router.post("/", response_model=GymRead, status_code=status.HTTP_201_CREATED, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER", "GYM_OWNER"]))])
def create_gym(gym: GymCreate):
    """Add a new gym."""
    new_id = (_gyms_db[-1].id + 1) if _gyms_db else 1
    new_gym = GymRead(id=new_id, **gym.dict())
    _gyms_db.append(new_gym)
    return new_gym

@gyms_router.get("/{gym_id}", response_model=GymRead, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER", "GYM_OWNER", "GYM_MANAGER", "CASHIER"]))])
def get_gym(gym_id: int):
    """Get a gym by ID."""
    for gym in _gyms_db:
        if gym.id == gym_id:
            return gym
    raise HTTPException(status_code=404, detail="Gym not found")

@gyms_router.put("/{gym_id}", response_model=GymRead, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER", "GYM_OWNER"]))])
def update_gym(gym_id: int, gym_update: GymUpdate):
    """Update gym info."""
    for idx, gym in enumerate(_gyms_db):
        if gym.id == gym_id:
            updated = gym.copy(update=gym_update.dict(exclude_unset=True))
            _gyms_db[idx] = updated
            return updated
    raise HTTPException(status_code=404, detail="Gym not found")

@gyms_router.delete("/{gym_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER", "GYM_OWNER"]))])
def delete_gym(gym_id: int):
    """Delete a gym."""
    global _gyms_db
    _gyms_db = [g for g in _gyms_db if g.id != gym_id]
    return
