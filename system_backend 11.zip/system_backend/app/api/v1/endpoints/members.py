"""
member.py

Endpoints for CRUD operations on gym members (was clients).
Author: Ndatimana Jean de Dieu
"""

from fastapi import APIRouter, HTTPException, status, Depends
from typing import List, Optional
from pydantic import BaseModel, EmailStr
from datetime import date
from app.core.rbac import RoleChecker

members_router = APIRouter(prefix="/members", tags=["Members"])

# --- Pydantic Schemas (in real project, import from schemas.member) ---
class MemberBase(BaseModel):
    name: str
    phone_number: Optional[str] = None
    email: Optional[EmailStr] = None
    registration_date: date

class MemberCreate(MemberBase):
    pass

class MemberUpdate(BaseModel):
    name: Optional[str] = None
    phone_number: Optional[str] = None
    email: Optional[EmailStr] = None
    registration_date: Optional[date] = None

class MemberRead(MemberBase):
    id: int
    gym_id: int
    user_id: Optional[int] = None

    class Config:
        orm_mode = True

# --- In-memory demo store (replace with DB) ---
_members_db: List[MemberRead] = []

# --- CRUD Endpoints ---

@members_router.get("/", response_model=List[MemberRead], dependencies=[Depends(RoleChecker(["CASHIER", "GYM_MANAGER", "GYM_OWNER"]))])
def list_members():
    """Retrieve all gym members."""
    return _members_db

@members_router.post("/", response_model=MemberRead, status_code=status.HTTP_201_CREATED, dependencies=[Depends(RoleChecker(["CASHIER", "GYM_MANAGER", "GYM_OWNER"]))])
def create_member(member: MemberCreate):
    """Create a new gym member."""
    new_id = (_members_db[-1].id + 1) if _members_db else 1
    gym_id = 1  # Replace with real gym context
    user_id = new_id + 100  # Placeholder user id
    new_member = MemberRead(id=new_id, gym_id=gym_id, user_id=user_id, **member.dict())
    _members_db.append(new_member)
    return new_member

@members_router.get("/{member_id}", response_model=MemberRead, dependencies=[Depends(RoleChecker(["CASHIER", "GYM_MANAGER", "GYM_OWNER", "MEMBER"]))])
def get_member(member_id: int):
    """Get a gym member by ID."""
    for member in _members_db:
        if member.id == member_id:
            return member
    raise HTTPException(status_code=404, detail="Member not found")

@members_router.put("/{member_id}", response_model=MemberRead, dependencies=[Depends(RoleChecker(["CASHIER", "GYM_MANAGER", "GYM_OWNER"]))])
def update_member(member_id: int, updates: MemberUpdate):
    """Update a gym member's information."""
    for idx, member in enumerate(_members_db):
        if member.id == member_id:
            updated = member.copy(update=updates.dict(exclude_unset=True))
            _members_db[idx] = updated
            return updated
    raise HTTPException(status_code=404, detail="Member not found")

@members_router.delete("/{member_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(RoleChecker(["CASHIER", "GYM_MANAGER", "GYM_OWNER"]))])
def delete_member(member_id: int):
    """Delete a gym member."""
    global _members_db
    _members_db = [m for m in _members_db if m.id != member_id]
    return

