"""
system_subscriptions.py

Endpoints for CRUD operations on gym system subscriptions.
Author: Ndatimana Jean de Dieu
"""

from fastapi import APIRouter, HTTPException, status, Depends
from typing import List, Optional
from pydantic import BaseModel
from datetime import date
from enum import Enum
from app.core.rbac import RoleChecker

system_subscriptions_router = APIRouter(
    prefix="/system-subscriptions",
    tags=["System Subscriptions"]
)

# --- Subscription Status Enum ---
class SubscriptionStatus(str, Enum):
    trial = "trial"
    active = "active"
    lapsed = "lapsed"
    cancelled = "cancelled"
    expired = "expired"

# --- Pydantic Schemas (replace with import from schemas.gym_subscription if available) ---
class SystemSubscriptionBase(BaseModel):
    gym_id: int
    plan_name: str
    monthly_price: float
    start_date: date
    end_date: Optional[date] = None
    status: SubscriptionStatus = SubscriptionStatus.trial
    last_payment_date: Optional[date] = None

class SystemSubscriptionCreate(SystemSubscriptionBase):
    pass

class SystemSubscriptionUpdate(BaseModel):
    plan_name: Optional[str] = None
    monthly_price: Optional[float] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    status: Optional[SubscriptionStatus] = None
    last_payment_date: Optional[date] = None

class SystemSubscriptionRead(SystemSubscriptionBase):
    id: int

    class Config:
        orm_mode = True
        use_enum_values = True

# --- In-memory demo store (replace with DB) ---
_system_subscriptions_db: List[SystemSubscriptionRead] = []

# --- CRUD Endpoints ---

@system_subscriptions_router.get("/", response_model=List[SystemSubscriptionRead], dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def list_system_subscriptions():
    """List all gym system subscriptions (system manager only)."""
    return _system_subscriptions_db

@system_subscriptions_router.post("/", response_model=SystemSubscriptionRead, status_code=status.HTTP_201_CREATED, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def create_system_subscription(subscription: SystemSubscriptionCreate):
    """Create a new gym system subscription (system manager only)."""
    new_id = (_system_subscriptions_db[-1].id + 1) if _system_subscriptions_db else 1
    new_sub = SystemSubscriptionRead(id=new_id, **subscription.dict())
    _system_subscriptions_db.append(new_sub)
    return new_sub

@system_subscriptions_router.get("/{gym_id}", response_model=SystemSubscriptionRead, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER", "GYM_OWNER"]))])
def get_system_subscription_by_gym(gym_id: int):
    """Get a specific gym's system subscription (system manager or gym owner)."""
    for sub in _system_subscriptions_db:
        if sub.gym_id == gym_id:
            return sub
    raise HTTPException(status_code=404, detail="Subscription not found")

@system_subscriptions_router.put("/{subscription_id}", response_model=SystemSubscriptionRead, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def update_system_subscription(subscription_id: int, updates: SystemSubscriptionUpdate):
    """Update a gym system subscription (system manager only)."""
    for idx, sub in enumerate(_system_subscriptions_db):
        if sub.id == subscription_id:
            updated = sub.copy(update=updates.dict(exclude_unset=True))
            _system_subscriptions_db[idx] = updated
            return updated
    raise HTTPException(status_code=404, detail="Subscription not found")

@system_subscriptions_router.delete("/{subscription_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def delete_system_subscription(subscription_id: int):
    """Delete (remove) a gym system subscription (system manager only)."""
    global _system_subscriptions_db
    _system_subscriptions_db = [s for s in _system_subscriptions_db if s.id != subscription_id]
    return

# --- Extra: Gym owner can view their own subscription status ---
@system_subscriptions_router.get("/my-status/{gym_id}", response_model=SystemSubscriptionRead, dependencies=[Depends(RoleChecker(["GYM_OWNER"]))])
def view_own_subscription(gym_id: int):
    """Gym owner can view their own gym's subscription status."""
    for sub in _system_subscriptions_db:
        if sub.gym_id == gym_id:
            return sub
    raise HTTPException(status_code=404, detail="Subscription not found")
