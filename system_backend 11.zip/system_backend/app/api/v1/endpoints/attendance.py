"""
attendance.py

Attendance endpoints for Smart Gym Management System.
Author: Ndatimana Jean de Dieu
"""

from fastapi import APIRouter, Depends, HTTPException, status
from typing import List, Optional
from pydantic import BaseModel
from datetime import date, datetime
from app.core.rbac import RoleChecker

attendance_router = APIRouter(prefix="/attendance", tags=["Attendance"])

# --- Pydantic Schemas ---
class AttendanceBase(BaseModel):
    user_id: Optional[int] = None
    member_id: Optional[int] = None  # Use member_id instead of client_id
    attendance_type: str
    date: date
    timestamp: Optional[datetime] = None

class AttendanceCreate(AttendanceBase):
    pass

class AttendanceUpdate(BaseModel):
    user_id: Optional[int] = None
    member_id: Optional[int] = None
    attendance_type: Optional[str] = None
    date: Optional[date] = None
    timestamp: Optional[datetime] = None

class AttendanceRead(AttendanceBase):
    id: int
    gym_id: int

    class Config:
        orm_mode = True

# --- In-memory Demo Store (Replace with DB Integration) ---
_attendance_db: List[AttendanceRead] = []

# --- Endpoints ---

@attendance_router.get("/", response_model=List[AttendanceRead], dependencies=[Depends(RoleChecker(["STAFF", "TRAINER", "CASHIER", "GYM_MANAGER"]))])
def list_attendance():
    """Retrieve all attendance records."""
    return _attendance_db

@attendance_router.post("/", response_model=AttendanceRead, status_code=status.HTTP_201_CREATED, dependencies=[Depends(RoleChecker(["STAFF", "TRAINER", "CASHIER", "GYM_MANAGER"]))])
def create_attendance(attendance: AttendanceCreate):
    """Create a new attendance record."""
    new_id = (_attendance_db[-1].id + 1) if _attendance_db else 1
    record = AttendanceRead(id=new_id, gym_id=1, **attendance.dict())  # gym_id is placeholder
    _attendance_db.append(record)
    return record

@attendance_router.get("/{attendance_id}", response_model=AttendanceRead, dependencies=[Depends(RoleChecker(["STAFF", "TRAINER", "CASHIER", "GYM_MANAGER", "MEMBER"]))])
def get_attendance(attendance_id: int):
    """Get a specific attendance record by ID."""
    for record in _attendance_db:
        if record.id == attendance_id:
            return record
    raise HTTPException(status_code=404, detail="Attendance not found")

@attendance_router.put("/{attendance_id}", response_model=AttendanceRead, dependencies=[Depends(RoleChecker(["STAFF", "TRAINER", "CASHIER", "GYM_MANAGER"]))])
def update_attendance(attendance_id: int, updates: AttendanceUpdate):
    """Update an existing attendance record."""
    for idx, record in enumerate(_attendance_db):
        if record.id == attendance_id:
            updated = record.copy(update=updates.dict(exclude_unset=True))
            _attendance_db[idx] = updated
            return updated
    raise HTTPException(status_code=404, detail="Attendance not found")

@attendance_router.delete("/{attendance_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(RoleChecker(["STAFF", "TRAINER", "CASHIER", "GYM_MANAGER"]))])
def delete_attendance(attendance_id: int):
    """Delete an attendance record."""
    global _attendance_db
    _attendance_db = [r for r in _attendance_db if r.id != attendance_id]
    return

