from fastapi import APIRouter

clients_router = APIRouter()
