"""
payments.py

Endpoints for CRUD operations on gym payments.
Author: Ndatimana Jean de Dieu
"""

from fastapi import APIRouter, HTTPException, status, Depends
from typing import List, Optional
from pydantic import BaseModel
from datetime import date
from app.core.rbac import RoleChecker

payments_router = APIRouter(prefix="/payments", tags=["Payments"])

# --- Pydantic Schemas (replace with import from schemas.payment if available) ---
class PaymentBase(BaseModel):
    member_id: int
    amount: float
    date: date
    payment_method: Optional[str] = None
    notes: Optional[str] = None

class PaymentCreate(PaymentBase):
    pass

class PaymentUpdate(BaseModel):
    member_id: Optional[int] = None
    amount: Optional[float] = None
    date: Optional[date] = None
    payment_method: Optional[str] = None
    notes: Optional[str] = None

class PaymentRead(PaymentBase):
    id: int
    gym_id: int

    class Config:
        orm_mode = True

# --- In-memory demo store (replace with DB) ---
_payments_db: List[PaymentRead] = []

# --- CRUD Endpoints ---

@payments_router.get("/", response_model=List[PaymentRead], dependencies=[Depends(RoleChecker(["CASHIER", "GYM_MANAGER", "GYM_OWNER", "MEMBER"]))])
def list_payments():
    """Retrieve all payments."""
    return _payments_db

@payments_router.post("/", response_model=PaymentRead, status_code=status.HTTP_201_CREATED, dependencies=[Depends(RoleChecker(["CASHIER", "GYM_MANAGER"]))])
def create_payment(payment: PaymentCreate):
    """Create a new payment for a member."""
    new_id = (_payments_db[-1].id + 1) if _payments_db else 1
    gym_id = 1  # Replace with real gym context
    new_payment = PaymentRead(id=new_id, gym_id=gym_id, **payment.dict())
    _payments_db.append(new_payment)
    return new_payment

@payments_router.get("/{payment_id}", response_model=PaymentRead, dependencies=[Depends(RoleChecker(["CASHIER", "GYM_MANAGER", "GYM_OWNER", "MEMBER"]))])
def get_payment(payment_id: int):
    """Get a payment by ID."""
    for payment in _payments_db:
        if payment.id == payment_id:
            return payment
    raise HTTPException(status_code=404, detail="Payment not found")

@payments_router.put("/{payment_id}", response_model=PaymentRead, dependencies=[Depends(RoleChecker(["CASHIER", "GYM_MANAGER"]))])
def update_payment(payment_id: int, updates: PaymentUpdate):
    """Update a payment."""
    for idx, payment in enumerate(_payments_db):
        if payment.id == payment_id:
            updated = payment.copy(update=updates.dict(exclude_unset=True))
            _payments_db[idx] = updated
            return updated
    raise HTTPException(status_code=404, detail="Payment not found")

@payments_router.delete("/{payment_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(RoleChecker(["CASHIER", "GYM_MANAGER"]))])
def delete_payment(payment_id: int):
    """Delete a payment."""
    global _payments_db
    _payments_db = [p for p in _payments_db if p.id != payment_id]
    return
