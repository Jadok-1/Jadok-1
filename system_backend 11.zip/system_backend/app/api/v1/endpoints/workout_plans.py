"""
workout_plans.py

Endpoints for CRUD operations on workout plans assigned to members.
Author: Ndatimana Jean de Dieu
"""

from fastapi import APIRouter, HTTPException, status, Depends
from typing import List, Optional
from pydantic import BaseModel
from app.core.rbac import RoleChecker

workout_plans_router = APIRouter(prefix="/workout-plans", tags=["Workout Plans"])

# --- Pydantic Schemas (replace with import from schemas.workout_plan if available) ---
class WorkoutPlanBase(BaseModel):
    member_id: int
    name: str
    description: Optional[str] = None
    duration_days: Optional[int] = None
    difficulty: Optional[str] = "beginner"  # beginner, intermediate, advanced

class WorkoutPlanCreate(WorkoutPlanBase):
    trainer_user_id: int

class WorkoutPlanUpdate(BaseModel):
    member_id: Optional[int] = None
    name: Optional[str] = None
    description: Optional[str] = None
    duration_days: Optional[int] = None
    difficulty: Optional[str] = None
    trainer_user_id: Optional[int] = None

class WorkoutPlanRead(WorkoutPlanBase):
    id: int
    gym_id: int
    trainer_user_id: int

    class Config:
        orm_mode = True

# --- In-memory demo store (replace with DB) ---
_workout_db: List[WorkoutPlanRead] = []

# --- CRUD Endpoints ---

@workout_plans_router.get("/", response_model=List[WorkoutPlanRead], dependencies=[Depends(RoleChecker(["TRAINER", "GYM_MANAGER", "MEMBER"]))])
def list_workout_plans():
    """Retrieve all workout plans."""
    return _workout_db

@workout_plans_router.post("/", response_model=WorkoutPlanRead, status_code=status.HTTP_201_CREATED, dependencies=[Depends(RoleChecker(["TRAINER", "GYM_MANAGER"]))])
def create_workout_plan(plan: WorkoutPlanCreate):
    """Create a new workout plan for a member."""
    new_id = (_workout_db[-1].id + 1) if _workout_db else 1
    gym_id = 1  # Replace with real gym context
    new_plan = WorkoutPlanRead(id=new_id, gym_id=gym_id, **plan.dict())
    _workout_db.append(new_plan)
    return new_plan

@workout_plans_router.get("/{plan_id}", response_model=WorkoutPlanRead, dependencies=[Depends(RoleChecker(["TRAINER", "GYM_MANAGER", "MEMBER"]))])
def get_workout_plan(plan_id: int):
    """Get a workout plan by ID."""
    for plan in _workout_db:
        if plan.id == plan_id:
            return plan
    raise HTTPException(status_code=404, detail="Workout plan not found")

@workout_plans_router.put("/{plan_id}", response_model=WorkoutPlanRead, dependencies=[Depends(RoleChecker(["TRAINER", "GYM_MANAGER"]))])
def update_workout_plan(plan_id: int, updates: WorkoutPlanUpdate):
    """Update a workout plan."""
    for idx, plan in enumerate(_workout_db):
        if plan.id == plan_id:
            updated = plan.copy(update=updates.dict(exclude_unset=True))
            _workout_db[idx] = updated
            return updated
    raise HTTPException(status_code=404, detail="Workout plan not found")

@workout_plans_router.delete("/{plan_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(RoleChecker(["TRAINER", "GYM_MANAGER"]))])
def delete_workout_plan(plan_id: int):
    """Delete a workout plan."""
    global _workout_db
    _workout_db = [p for p in _workout_db if p.id != plan_id]
    return
