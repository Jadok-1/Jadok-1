"""
system.py

System-level endpoints for Smart Gym Management System.
Author: Ndatimana Jean de Dieu
"""

from fastapi import APIRouter, status, Depends
from app.core.rbac import RoleChecker

system_router = APIRouter(prefix="/system", tags=["System"])

@system_router.get("/health", status_code=status.HTTP_200_OK)
def health_check():
    """System health check endpoint."""
    return {"status": "ok"}

@system_router.get("/stats", dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def get_system_stats():
    """View system-wide statistics (restricted to system managers)."""
    # Replace with real stats logic
    return {
        "total_gyms": 2,
        "total_members": 250,
        "total_active_subscriptions": 187,
        "total_payments": 1785
    }

@system_router.get("/settings", dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def get_system_settings():
    """View or manage global system settings (restricted to system managers)."""
    # Replace with real config/settings logic
    return {
        "maintenance_mode": False,
        "version": "1.0.0",
        "default_currency": "RWF"
    }
