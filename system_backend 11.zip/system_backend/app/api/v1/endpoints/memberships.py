"""
memberships.py

Endpoints for CRUD operations on gym memberships.
Author: Ndatimana Jean de Dieu
"""

from fastapi import APIRouter, HTTPException, status, Depends
from typing import List, Optional
from pydantic import BaseModel
from datetime import date
from app.core.rbac import RoleChecker

memberships_router = APIRouter(prefix="/memberships", tags=["Memberships"])

# --- Pydantic Schemas (replace with import from schemas.membership if available) ---
class MembershipBase(BaseModel):
    member_id: int
    membership_type: str
    price: float
    discount_percent: float = 0.0
    start_date: date
    end_date: date

class MembershipCreate(MembershipBase):
    pass

class MembershipUpdate(BaseModel):
    member_id: Optional[int] = None
    membership_type: Optional[str] = None
    price: Optional[float] = None
    discount_percent: Optional[float] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None

class MembershipRead(MembershipBase):
    id: int
    gym_id: int
    creator_user_id: int

    class Config:
        orm_mode = True

# --- In-memory demo store (replace with DB) ---
_memberships_db: List[MembershipRead] = []

# --- CRUD Endpoints ---

@memberships_router.get("/", response_model=List[MembershipRead], dependencies=[Depends(RoleChecker(["CASHIER", "GYM_MANAGER", "GYM_OWNER", "MEMBER"]))])
def list_memberships():
    """Retrieve all gym memberships."""
    return _memberships_db

@memberships_router.post("/", response_model=MembershipRead, status_code=status.HTTP_201_CREATED, dependencies=[Depends(RoleChecker(["CASHIER", "GYM_MANAGER", "GYM_OWNER"]))])
def create_membership(membership: MembershipCreate):
    """Create a new gym membership."""
    new_id = (_memberships_db[-1].id + 1) if _memberships_db else 1
    gym_id = 1  # Replace with real gym from context
    creator_user_id = 1  # Replace with real user from auth/session
    new_membership = MembershipRead(id=new_id, gym_id=gym_id, creator_user_id=creator_user_id, **membership.dict())
    _memberships_db.append(new_membership)
    return new_membership

@memberships_router.get("/{membership_id}", response_model=MembershipRead, dependencies=[Depends(RoleChecker(["CASHIER", "GYM_MANAGER", "GYM_OWNER", "MEMBER"]))])
def get_membership(membership_id: int):
    """Get a gym membership by ID."""
    for membership in _memberships_db:
        if membership.id == membership_id:
            return membership
    raise HTTPException(status_code=404, detail="Membership not found")

@memberships_router.put("/{membership_id}", response_model=MembershipRead, dependencies=[Depends(RoleChecker(["CASHIER", "GYM_MANAGER", "GYM_OWNER"]))])
def update_membership(membership_id: int, updates: MembershipUpdate):
    """Update a gym membership."""
    for idx, membership in enumerate(_memberships_db):
        if membership.id == membership_id:
            updated = membership.copy(update=updates.dict(exclude_unset=True))
            _memberships_db[idx] = updated
            return updated
    raise HTTPException(status_code=404, detail="Membership not found")

@memberships_router.delete("/{membership_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(RoleChecker(["CASHIER", "GYM_MANAGER", "GYM_OWNER"]))])
def delete_membership(membership_id: int):
    """Delete a gym membership."""
    global _memberships_db
    _memberships_db = [m for m in _memberships_db if m.id != membership_id]
    return
