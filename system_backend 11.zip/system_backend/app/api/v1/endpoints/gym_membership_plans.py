"""
gym_membership_plans.py

Endpoints for CRUD operations on gym membership plans.
Author: Ndatimana Jean de Dieu
"""

from fastapi import APIRouter, HTTPException, status, Depends
from typing import List, Optional
from pydantic import BaseModel
from app.core.rbac import RoleChecker

gym_membership_plans_router = APIRouter(prefix="/gym-membership-plans", tags=["Gym Membership Plans"])

# --- Pydantic Schemas (replace with import from schemas.gym_membership_plan_template if available) ---
class GymMembershipPlanBase(BaseModel):
    name: str
    duration_days: int
    price: float
    discount_percent: Optional[float] = 0.0

class GymMembershipPlanCreate(GymMembershipPlanBase):
    pass

class GymMembershipPlanUpdate(BaseModel):
    name: Optional[str] = None
    duration_days: Optional[int] = None
    price: Optional[float] = None
    discount_percent: Optional[float] = None

class GymMembershipPlanRead(GymMembershipPlanBase):
    id: int
    gym_id: int

    class Config:
        orm_mode = True

# --- In-memory demo store (replace with DB) ---
_plans_db: List[GymMembershipPlanRead] = []

# --- CRUD Endpoints ---

@gym_membership_plans_router.get("/", response_model=List[GymMembershipPlanRead], dependencies=[Depends(RoleChecker(["GYM_MANAGER", "GYM_OWNER", "CASHIER", "MEMBER"]))])
def list_plans():
    """Retrieve all gym membership plans."""
    return _plans_db

@gym_membership_plans_router.post("/", response_model=GymMembershipPlanRead, status_code=status.HTTP_201_CREATED, dependencies=[Depends(RoleChecker(["GYM_MANAGER", "GYM_OWNER"]))])
def create_plan(plan: GymMembershipPlanCreate):
    """Create a new gym membership plan."""
    new_id = (_plans_db[-1].id + 1) if _plans_db else 1
    gym_id = 1  # Replace with gym from user/session
    new_plan = GymMembershipPlanRead(id=new_id, gym_id=gym_id, **plan.dict())
    _plans_db.append(new_plan)
    return new_plan

@gym_membership_plans_router.get("/{plan_id}", response_model=GymMembershipPlanRead, dependencies=[Depends(RoleChecker(["GYM_MANAGER", "GYM_OWNER", "CASHIER", "MEMBER"]))])
def get_plan(plan_id: int):
    """Get a gym membership plan by ID."""
    for plan in _plans_db:
        if plan.id == plan_id:
            return plan
    raise HTTPException(status_code=404, detail="Plan not found")

@gym_membership_plans_router.put("/{plan_id}", response_model=GymMembershipPlanRead, dependencies=[Depends(RoleChecker(["GYM_MANAGER", "GYM_OWNER"]))])
def update_plan(plan_id: int, updates: GymMembershipPlanUpdate):
    """Update a gym membership plan."""
    for idx, plan in enumerate(_plans_db):
        if plan.id == plan_id:
            updated = plan.copy(update=updates.dict(exclude_unset=True))
            _plans_db[idx] = updated
            return updated
    raise HTTPException(status_code=404, detail="Plan not found")

@gym_membership_plans_router.delete("/{plan_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(RoleChecker(["GYM_MANAGER", "GYM_OWNER"]))])
def delete_plan(plan_id: int):
    """Delete a gym membership plan."""
    global _plans_db
    _plans_db = [p for p in _plans_db if p.id != plan_id]
    return
