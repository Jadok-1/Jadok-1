"""
nutrition_plans.py

Endpoints for CRUD operations on nutrition plans assigned to members.
Author: Ndatimana Jean de Dieu
"""

from fastapi import APIRouter, HTTPException, status, Depends
from typing import List, Optional
from pydantic import BaseModel
from datetime import date
from app.core.rbac import RoleChecker

nutrition_plans_router = APIRouter(prefix="/nutrition-plans", tags=["Nutrition Plans"])

# --- Pydantic Schemas (replace with import from schemas.nutrition_plan if available) ---
class NutritionPlanBase(BaseModel):
    member_id: int
    title: str
    description: Optional[str] = None
    assigned_date: date

class NutritionPlanCreate(NutritionPlanBase):
    trainer_user_id: int

class NutritionPlanUpdate(BaseModel):
    member_id: Optional[int] = None
    title: Optional[str] = None
    description: Optional[str] = None
    assigned_date: Optional[date] = None
    trainer_user_id: Optional[int] = None

class NutritionPlanRead(NutritionPlanBase):
    id: int
    gym_id: int
    trainer_user_id: int

    class Config:
        orm_mode = True

# --- In-memory demo store (replace with DB) ---
_nutrition_db: List[NutritionPlanRead] = []

# --- CRUD Endpoints ---

@nutrition_plans_router.get("/", response_model=List[NutritionPlanRead], dependencies=[Depends(RoleChecker(["TRAINER", "GYM_MANAGER", "MEMBER"]))])
def list_nutrition_plans():
    """Retrieve all nutrition plans."""
    return _nutrition_db

@nutrition_plans_router.post("/", response_model=NutritionPlanRead, status_code=status.HTTP_201_CREATED, dependencies=[Depends(RoleChecker(["TRAINER", "GYM_MANAGER"]))])
def create_nutrition_plan(plan: NutritionPlanCreate):
    """Create a new nutrition plan for a member."""
    new_id = (_nutrition_db[-1].id + 1) if _nutrition_db else 1
    gym_id = 1  # Replace with real gym context
    new_plan = NutritionPlanRead(id=new_id, gym_id=gym_id, **plan.dict())
    _nutrition_db.append(new_plan)
    return new_plan

@nutrition_plans_router.get("/{plan_id}", response_model=NutritionPlanRead, dependencies=[Depends(RoleChecker(["TRAINER", "GYM_MANAGER", "MEMBER"]))])
def get_nutrition_plan(plan_id: int):
    """Get a nutrition plan by ID."""
    for plan in _nutrition_db:
        if plan.id == plan_id:
            return plan
    raise HTTPException(status_code=404, detail="Nutrition plan not found")

@nutrition_plans_router.put("/{plan_id}", response_model=NutritionPlanRead, dependencies=[Depends(RoleChecker(["TRAINER", "GYM_MANAGER"]))])
def update_nutrition_plan(plan_id: int, updates: NutritionPlanUpdate):
    """Update a nutrition plan."""
    for idx, plan in enumerate(_nutrition_db):
        if plan.id == plan_id:
            updated = plan.copy(update=updates.dict(exclude_unset=True))
            _nutrition_db[idx] = updated
            return updated
    raise HTTPException(status_code=404, detail="Nutrition plan not found")

@nutrition_plans_router.delete("/{plan_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(RoleChecker(["TRAINER", "GYM_MANAGER"]))])
def delete_nutrition_plan(plan_id: int):
    """Delete a nutrition plan."""
    global _nutrition_db
    _nutrition_db = [p for p in _nutrition_db if p.id != plan_id]
    return
