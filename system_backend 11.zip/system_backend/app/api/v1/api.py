"""
api.py

Main API router for Smart Gym Management System.
Author: Ndatimana Jean de Dieu
"""

from fastapi import APIRouter

# --- Resource-based routers ---
from app.api.v1.endpoints import (
    auth, users, gyms, members, payments, memberships,
    workout_plans, nutrition_plans, gym_membership_plans,
    attendance, equipment, system
)

# --- Role-based routers ---
from app.routers import (
    member_router,
    trainer_router,
    cleaner_router,
    cashier_router,
    gym_manager_router,
    gym_owner_router,
    system_manager_router
)

api_router = APIRouter()

# Resource-based endpoints
api_router.include_router(auth.auth_router)
api_router.include_router(users.users_router)
api_router.include_router(gyms.gyms_router)
api_router.include_router(members.members_router)           # renamed from clients
api_router.include_router(payments.payments_router)
api_router.include_router(memberships.memberships_router)
api_router.include_router(workout_plans.workout_plans_router)
api_router.include_router(nutrition_plans.nutrition_plans_router)
api_router.include_router(gym_membership_plans.gym_membership_plans_router)
api_router.include_router(attendance.attendance_router)
api_router.include_router(equipment.equipment_router)
api_router.include_router(system.system_router)

# Role-based endpoints (with URL prefixes)
api_router.include_router(member_router.router, prefix="/member", tags=["Member"])
api_router.include_router(trainer_router.router, prefix="/trainer", tags=["Trainer"])
api_router.include_router(cleaner_router.router, prefix="/cleaner", tags=["Cleaner"])
api_router.include_router(cashier_router.router, prefix="/cashier", tags=["Cashier"])
api_router.include_router(gym_manager_router.router, prefix="/gym-manager", tags=["Gym Manager"])
api_router.include_router(gym_owner_router.router, prefix="/gym-owner", tags=["Gym Owner"])
api_router.include_router(system_manager_router.router, prefix="/system-manager", tags=["System Manager"])
