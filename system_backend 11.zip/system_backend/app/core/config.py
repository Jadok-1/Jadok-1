"""
config.py

App-wide settings and environment configuration for Smart Gym Management System.
Author: Ndatimana Jean de Dieu
"""

from pydantic import BaseSettings, EmailStr

class Settings(BaseSettings):
    # --- Project and DB settings ---
    PROJECT_NAME: str = "Smart Gym Management System"
    ENV: str = "development"
    DATABASE_URL: str = "postgresql://user:password@localhost/gymdb"

    # --- JWT & Security ---
    JWT_SECRET_KEY: str = "supersecretkey"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    ALGORITHM: str = "HS256"

    # --- Email (SMTP) Settings ---
    EMAIL_SENDER: EmailStr = "your@gmail.com"
    SMTP_HOST: str = "smtp.gmail.com"
    SMTP_PORT: int = 587
    SMTP_USER: EmailStr = "your@gmail.com"
    SMTP_PASSWORD: str = "your_app_password"

    # --- WhatsApp API ---
    WHATSAPP_API_URL: str = "https://api.whatsapp.com/send"

    # --- Twilio Settings ---
    TWILIO_ACCOUNT_SID: str = ""
    TWILIO_AUTH_TOKEN: str = ""
    TWILIO_PHONE_NUMBER: str = ""

    class Config:
        env_file = ".env"
        case_sensitive = True

settings = Settings()
