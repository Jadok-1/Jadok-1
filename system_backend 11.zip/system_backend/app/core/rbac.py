"""
rbac.py

Role-based access control utilities for Smart Gym Management System.
Author: Ndatimana Jean de Dieu
"""

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError
from enum import Enum
from app.core.config import settings

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

class Role(str, Enum):
    MEMBER = "MEMBER"
    TRAINER = "TRAINER"
    CASHIER = "CASHIER"
    GYM_MANAGER = "GYM_MANAGER"
    GYM_OWNER = "GYM_OWNER"
    SYSTEM_MANAGER = "SYSTEM_MANAGER"
    CLEANER = "CLEANER"
    STAFF = "STAFF"

def get_current_user(token: str = Depends(oauth2_scheme)):
    """
    Decode JWT token and extract user info including role.
    Raises HTTP 401 if invalid.
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.JWT_SECRET_KEY, algorithms=[settings.ALGORITHM])
        username: str = payload.get("sub")
        role: str = payload.get("role")
        if username is None or role is None:
            raise credentials_exception
        return {"username": username, "role": role}
    except JWTError:
        raise credentials_exception

class RoleChecker:
    """
    Dependency to enforce that the current user has an allowed role.
    """
    def __init__(self, allowed_roles: list[Role]):
        self.allowed_roles = [role.value if isinstance(role, Role) else role for role in allowed_roles]

    def __call__(self, user=Depends(get_current_user)):
        if user["role"] not in self.allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Operation not permitted"
            )
        return user
