"""
dependencies.py

FastAPI dependencies for DB session, user authentication, and role-based access.
Author: Ndatimana Jean de Dieu
"""

from typing import Generator
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer
from sqlalchemy.orm import Session
from app.db.session import SessionLocal
from app.models.user import User, UserRole
from app.models.member import Member
from app.core import security

def get_db() -> Generator:
    """Dependency to provide a SQLAlchemy session per request."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

oauth2_scheme = HTTPBearer()

def get_current_user(db: Session = Depends(get_db), token_obj = Depends(oauth2_scheme)) -> User:
    """
    Validates JWT token and returns the current user.
    Raises 401 if not valid or user not found.
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    token = token_obj.credentials
    token_data = security.verify_token(token)
    if token_data is None:
        raise credentials_exception
    email: str = token_data.get("sub")
    if email is None:
        raise credentials_exception
    user = db.query(User).filter(User.email == email).first()
    if user is None:
        raise credentials_exception
    return user

# --- Role dependencies ---

def get_current_active_user_in_gym(current_user: User = Depends(get_current_user)) -> User:
    """
    Ensures user is linked to a gym and is not a system manager.
    """
    if current_user.gym_id is None or current_user.role == UserRole.system_manager:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User does not belong to a gym or is a System Manager (global user)",
        )
    return current_user

def get_system_manager(current_user: User = Depends(get_current_user)) -> User:
    """Allows only system managers."""
    if current_user.role != UserRole.system_manager:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized: Requires System Manager role",
        )
    return current_user

def get_gym_owner(current_user: User = Depends(get_current_active_user_in_gym)) -> User:
    """Allows only gym owners."""
    if current_user.role != UserRole.gym_owner:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized: Requires Gym Owner role",
        )
    return current_user

def get_staff(current_user: User = Depends(get_current_active_user_in_gym)) -> User:
    """Allows only staff."""
    if current_user.role != UserRole.staff:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized: Requires Staff role",
        )
    return current_user

def get_trainer(current_user: User = Depends(get_current_active_user_in_gym)) -> User:
    """Allows only trainers."""
    if current_user.role != UserRole.trainer:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized: Requires Trainer role",
        )
    return current_user

def get_member_user(current_user: User = Depends(get_current_active_user_in_gym)) -> User:
    """Allows only members."""
    if current_user.role != UserRole.member:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized: Requires Member role",
        )
    return current_user

# --- Profile dependencies ---

def get_current_member_profile(
    db: Session = Depends(get_db), 
    member_user: User = Depends(get_member_user)
) -> Member:
    """
    Get the member profile for the current user.
    """
    member_profile = db.query(Member).filter(
        Member.user_id == member_user.id, 
        Member.gym_id == member_user.gym_id
    ).first()
    if not member_profile:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Member profile not found for this user. Data inconsistency."
        )
    return member_profile

# --- Multi-role dependencies ---

def get_owner_or_staff(current_user: User = Depends(get_current_active_user_in_gym)) -> User:
    """Allows only gym owner or staff."""
    if current_user.role not in [UserRole.gym_owner, UserRole.staff]:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized: Requires Owner or Staff role")
    return current_user

def get_owner_staff_or_trainer(current_user: User = Depends(get_current_active_user_in_gym)) -> User:
    """Allows gym owner, staff, or trainer."""
    if current_user.role not in [UserRole.gym_owner, UserRole.staff, UserRole.trainer]:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized: Requires Owner, Staff, or Trainer role")
    return current_user
