"""
notifications.py

Notification utilities for Smart Gym Management System.
Author: Ndatimana Jean de Dieu
"""

from datetime import date
from app.core.config import settings
from sqlalchemy.orm import Session
from app.crud import member as crud_member

def send_membership_expiry_notification(
    db: Session,
    member_id: int,
    membership_end_date: date,
    days_left: int,
    gym_name: str = None
):
    """
    Notify a member that their gym membership is about to expire.
    Returns a status dict.
    """
    gym_name = gym_name or getattr(settings, "PROJECT_NAME", "[Gym Name]")

    member = crud_member.get_member(db, member_id=member_id)
    if not member:
        msg = f"Notification failed: Member ID {member_id} not found."
        print(msg)
        return {"success": False, "message": msg}

    contact_info = member.email or member.phone_number
    contact_type = 'email' if member.email else ('whatsapp' if member.phone_number else None)
    member_name = member.name

    if not contact_info or not contact_type:
        msg = f"Notification failed: No contact info for member {member_name} (ID: {member_id})"
        print(msg)
        return {"success": False, "message": msg}

    subject = f"Your Membership at {gym_name} is Expiring Soon!"
    body = f"""
    Hi {member_name},

    This is a friendly reminder that your membership at {gym_name} is expiring on {membership_end_date.strftime('%Y-%m-%d')}.
    You have {days_left} days left.

    Please visit the gym or log in to your account to renew your membership and continue enjoying our facilities!

    Best regards,
    The {gym_name} Team
    """

    print(f"--- Notification Triggered ---")
    print(f"Attempting to send '{contact_type}' expiry notification for {member_name} (ID: {member_id})")
    print(f"Membership ends on: {membership_end_date}")
    print(f"To: {contact_info}")
    print(f"--- End Notification Triggered ---")

    # Placeholder: implement actual email/whatsapp send below.
    # if contact_type == "email":
    #     send_email(contact_info, subject, body)
    # elif contact_type == "whatsapp":
    #     send_whatsapp_message(contact_info, body)

    return {
        "success": True,
        "message": f"Expiry notification attempted via {contact_type}",
        "to": contact_info,
        "contact_type": contact_type
    }

def send_email(recipient: str, subject: str, body: str):
    """
    Placeholder for sending an email.
    Returns status dict.
    """
    print(f"[EMAIL PLACEHOLDER] Sending email to {recipient} with subject '{subject}'")
    return {"success": True, "message": "Email sent (placeholder)", "to": recipient}

def send_whatsapp_message(phone_number: str, message: str):
    """
    Placeholder for sending a WhatsApp message.
    Returns status dict.
    """
    print(f"[WHATSAPP PLACEHOLDER] Sending WhatsApp message to {phone_number}")
    return {"success": True, "message": "WhatsApp message sent (placeholder)", "to": phone_number}
