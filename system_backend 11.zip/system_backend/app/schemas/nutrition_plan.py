"""
nutrition_plan.py

Pydantic schemas for nutrition plan endpoints.
Author: Ndatimana Jean de Dieu
"""

from pydantic import BaseModel
from datetime import date
from typing import Optional

class NutritionPlanBase(BaseModel):
    member_id: int
    title: str
    description: Optional[str] = None
    assigned_date: date

class NutritionPlanCreate(NutritionPlanBase):
    trainer_user_id: int

class NutritionPlanUpdate(BaseModel):
    member_id: Optional[int] = None
    title: Optional[str] = None
    description: Optional[str] = None
    assigned_date: Optional[date] = None
    trainer_user_id: Optional[int] = None

class NutritionPlanRead(NutritionPlanBase):
    id: int
    gym_id: int
    trainer_user_id: int

    class Config:
        orm_mode = True
