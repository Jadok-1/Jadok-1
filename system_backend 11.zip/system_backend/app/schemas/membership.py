"""
membership.py

Pydantic schemas for gym membership management.
Author: Ndatimana Jean de Dieu
"""

from pydantic import BaseModel
from datetime import date
from typing import Optional

class MembershipBase(BaseModel):
    member_id: int
    plan_id: int
    membership_type: str
    price: float
    discount_percent: float = 0.0
    start_date: date
    end_date: date

class MembershipCreate(MembershipBase):
    creator_user_id: int
    gym_id: int

class MembershipUpdate(BaseModel):
    member_id: Optional[int] = None
    plan_id: Optional[int] = None
    membership_type: Optional[str] = None
    price: Optional[float] = None
    discount_percent: Optional[float] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    creator_user_id: Optional[int] = None
    gym_id: Optional[int] = None

class MembershipRead(MembershipBase):
    id: int
    gym_id: int
    creator_user_id: int

    class Config:
        orm_mode = True
