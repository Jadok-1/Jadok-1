from pydantic import BaseModel

class GymBase(BaseModel):
    name: str

class GymCreate(GymBase):
    pass

class GymUpdate(GymBase):
    pass

class GymRead(GymBase):
    id: int

    class Config:
        orm_mode = True
