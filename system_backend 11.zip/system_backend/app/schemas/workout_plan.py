"""
workout_plan.py

Pydantic schemas for workout plans.
Author: Ndatimana Jean de Dieu
"""

from pydantic import BaseModel
from typing import Optional
from app.models.workout_plan import WorkoutPlan  # Import for Enum if needed

class WorkoutPlanBase(BaseModel):
    member_id: int
    name: str
    description: Optional[str] = None
    duration_days: Optional[int] = None
    difficulty: Optional[str] = "beginner"

class WorkoutPlanCreate(WorkoutPlanBase):
    trainer_user_id: int

class WorkoutPlanUpdate(BaseModel):
    member_id: Optional[int] = None
    name: Optional[str] = None
    description: Optional[str] = None
    duration_days: Optional[int] = None
    difficulty: Optional[str] = None
    trainer_user_id: Optional[int] = None

class WorkoutPlanRead(WorkoutPlanBase):
    id: int
    gym_id: int
    trainer_user_id: int

    class Config:
        orm_mode = True
