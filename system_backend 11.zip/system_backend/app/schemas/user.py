"""
user.py

Pydantic schemas for user management endpoints.
Author: Ndatimana Jean de Dieu
"""

from pydantic import BaseModel, EmailStr
from typing import Optional
from app.models.user import UserRole

class UserBase(BaseModel):
    email: EmailStr
    full_name: Optional[str] = None
    role: UserRole
    gym_id: Optional[int] = None

class UserCreate(UserBase):
    password: str

class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    full_name: Optional[str] = None
    password: Optional[str] = None
    role: Optional[UserRole] = None
    gym_id: Optional[int] = None

class UserRead(UserBase):
    id: int

    class Config:
        orm_mode = True
        use_enum_values = True
