"""
expense.py

Pydantic schemas for expenses.
Author: Ndatimana Jean de Dieu
"""

from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class ExpenseBase(BaseModel):
    gym_id: int
    branch_id: Optional[int] = None
    description: str
    amount: float

class ExpenseCreate(ExpenseBase):
    pass

class ExpenseUpdate(BaseModel):
    gym_id: Optional[int] = None
    branch_id: Optional[int] = None
    description: Optional[str] = None
    amount: Optional[float] = None

class ExpenseRead(ExpenseBase):
    id: int
    created_at: datetime

    class Config:
        orm_mode = True
