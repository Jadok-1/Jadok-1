"""
invoice.py

Pydantic schemas for invoices.
Author: Ndatimana Jean de Dieu
"""

from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class InvoiceBase(BaseModel):
    member_id: int
    gym_id: int
    amount: float
    due_date: datetime
    paid: bool = False
    deleted: bool = False
    delete_reason: Optional[str] = None

class InvoiceCreate(InvoiceBase):
    pass

class InvoiceUpdate(BaseModel):
    member_id: Optional[int] = None
    gym_id: Optional[int] = None
    amount: Optional[float] = None
    due_date: Optional[datetime] = None
    paid: Optional[bool] = None
    deleted: Optional[bool] = None
    delete_reason: Optional[str] = None

class InvoiceRead(InvoiceBase):
    id: int
    created_at: datetime

    class Config:
        orm_mode = True
