"""
gym_subscription.py

SQLAlchemy model for gym system subscriptions.
Author: Ndatimana Jean de Dieu
"""

import enum
from sqlalchemy import Column, Integer, String, ForeignKey, Date, Float, Enum
from app.db.session import Base

class SubscriptionStatus(str, enum.Enum):
    trial = "trial"
    active = "active"
    lapsed = "lapsed"
    cancelled = "cancelled"
    expired = "expired"

class GymSubscription(Base):
    """
    Represents a subscription for a gym to the management system.
    """
    __tablename__ = "gym_subscriptions"

    id = Column(Integer, primary_key=True, index=True)
    gym_id = Column(Integer, ForeignKey("gyms.id"), unique=True, nullable=False)
    plan_id = Column(Integer, ForeignKey("system_subscription_plans.id"), nullable=False)  # NEW
    # Optionally keep for history:
    plan_name = Column(String, nullable=False)
    monthly_price = Column(Float, nullable=False)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=True)
    status = Column(
        Enum(SubscriptionStatus),
        default=SubscriptionStatus.trial,
        nullable=False
    )
    last_payment_date = Column(Date, nullable=True)
