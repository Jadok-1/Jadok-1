"""
attendance.py

Pydantic schemas for Attendance endpoints.
Author: Ndatimana Jean de Dieu
"""

from pydantic import BaseModel
from datetime import date, datetime
from typing import Optional
from app.models.attendance import AttendanceType

class AttendanceBase(BaseModel):
    user_id: Optional[int] = None
    member_id: Optional[int] = None  # was client_id
    attendance_type: AttendanceType
    date: date
    timestamp: Optional[datetime] = None

class AttendanceCreate(AttendanceBase):
    pass

class AttendanceUpdate(BaseModel):
    user_id: Optional[int] = None
    member_id: Optional[int] = None  # was client_id
    attendance_type: Optional[AttendanceType] = None
    date: Optional[date] = None
    timestamp: Optional[datetime] = None

class AttendanceRead(AttendanceBase):
    id: int
    gym_id: int

    class Config:
        orm_mode = True
        use_enum_values = True
