"""
member.py

Pydantic schemas for gym members.
Author: Ndatimana Jean de Dieu
"""

from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import date

class MemberBase(BaseModel):
    name: str
    phone_number: Optional[str] = None
    email: Optional[EmailStr] = None
    registration_date: date

class MemberCreate(MemberBase):
    pass

class MemberUpdate(BaseModel):
    name: Optional[str] = None
    phone_number: Optional[str] = None
    email: Optional[EmailStr] = None
    registration_date: Optional[date] = None

class MemberRead(MemberBase):
    id: int
    gym_id: int
    user_id: Optional[int] = None

    class Config:
        orm_mode = True
