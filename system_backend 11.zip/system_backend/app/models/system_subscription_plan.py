"""
system_subscription_plan.py

Pydantic schemas for SaaS system subscription plans.
Author: Ndatimana Jean de Dieu
"""

from pydantic import BaseModel
from typing import Optional

class SystemSubscriptionPlanBase(BaseModel):
    name: str
    price: float
    duration_days: int
    max_branches: int
    max_staff: int
    max_members: int
    features: Optional[str] = None

class SystemSubscriptionPlanCreate(SystemSubscriptionPlanBase):
    pass

class SystemSubscriptionPlanUpdate(BaseModel):
    name: Optional[str] = None
    price: Optional[float] = None
    duration_days: Optional[int] = None
    max_branches: Optional[int] = None
    max_staff: Optional[int] = None
    max_members: Optional[int] = None
    features: Optional[str] = None

class SystemSubscriptionPlanRead(SystemSubscriptionPlanBase):
    id: int

    class Config:
        orm_mode = True
