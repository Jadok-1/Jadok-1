"""
attendance.py

SQLAlchemy model for tracking gym attendance records.
Author: Ndatimana Jean de Dieu
"""

import enum
from sqlalchemy import Column, Integer, Enum, ForeignKey, Date, DateTime, func
from app.db.session import Base

class AttendanceType(str, enum.Enum):
    member = "member"
    staff = "staff"
    trainer = "trainer"
    cleaner = "cleaner"

class Attendance(Base):
    """
    Represents a single attendance event (check-in/check-out) at a gym.
    """
    __tablename__ = "attendance"

    id = Column(Integer, primary_key=True, index=True)
    gym_id = Column(Integer, ForeignKey("gyms.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    member_id = Column(Integer, ForeignKey("members.id"), nullable=True)  # renamed from client_id
    attendance_type = Column(Enum(AttendanceType), nullable=False)
    date = Column(Date, nullable=False)
    timestamp = Column(DateTime, nullable=True, default=func.now())  # Automatically set timestamp on record creation
