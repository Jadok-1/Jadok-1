"""
equipment_issue.py

SQLAlchemy model for equipment issue reports in the gym.
Author: Ndatimana Jean de Dieu
"""

from sqlalchemy import Column, Integer, ForeignKey, Text, Date, func
from app.db.session import Base

class EquipmentIssue(Base):
    """
    Represents a reported issue for a specific gym equipment item.
    """
    __tablename__ = "equipment_issues"

    id = Column(Integer, primary_key=True, index=True)
    gym_id = Column(Integer, ForeignKey("gyms.id"), nullable=False, index=True)
    equipment_id = Column(Integer, ForeignKey("equipment.id"), nullable=False)
    reported_by_user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    reported_date = Column(Date, nullable=False, default=func.now())  # Auto-set date if not provided
    description = Column(Text, nullable=False)
