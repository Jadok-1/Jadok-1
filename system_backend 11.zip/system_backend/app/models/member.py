"""
member.py

SQLAlchemy model for gym members.
Author: Ndatimana Jean de Dieu
"""

from sqlalchemy import Column, Integer, String, ForeignKey, Date, func
from app.db.session import Base

class Member(Base):
    """
    Represents a gym member.
    """
    __tablename__ = "members"

    id = Column(Integer, primary_key=True, index=True)
    gym_id = Column(Integer, ForeignKey("gyms.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=True)
    name = Column(String, nullable=False)
    phone_number = Column(String, index=True, nullable=True)
    email = Column(String, index=True, nullable=True)
    registration_date = Column(Date, default=func.now())  # Automatically set date on registration
