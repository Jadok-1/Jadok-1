from sqlalchemy import Column, Integer, String, ForeignKey, Date
from app.db.session import Base

class Client(Base):
    __tablename__ = "clients"

    id = Column(Integer, primary_key=True, index=True)
    gym_id = Column(Integer, ForeignKey("gyms.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=True)
    name = Column(String, nullable=False)
    phone_number = Column(String, index=True, nullable=True)
    email = Column(String, index=True, nullable=True)
    registration_date = Column(Date)
