"""
membership.py

SQLAlchemy model for gym memberships (member subscriptions to gym plans).
Author: Ndatimana Jean de Dieu
"""

from sqlalchemy import Column, Integer, String, Float, ForeignKey, Date
from app.db.session import Base

class Membership(Base):
    """
    Represents a member's subscription (membership) to a gym and plan.
    """
    __tablename__ = "memberships"

    id = Column(Integer, primary_key=True, index=True)
    gym_id = Column(Integer, ForeignKey("gyms.id"), nullable=False, index=True)
    member_id = Column(Integer, ForeignKey("members.id"), nullable=False, index=True)
    plan_id = Column(Integer, ForeignKey("gym_membership_plan_templates.id"), nullable=False)
    membership_type = Column(String, nullable=False)
    price = Column(Float, nullable=False)
    discount_percent = Column(Float, default=0.0)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    creator_user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
