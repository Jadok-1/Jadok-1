"""
user.py

SQLAlchemy model for system users with roles.
Author: Ndatimana Jean de Dieu
"""

import enum
from sqlalchemy import Column, Integer, String, ForeignKey, Enum
from app.db.session import Base

class UserRole(str, enum.Enum):
    system_manager = "system_manager"
    gym_owner = "gym_owner"
    gym_manager = "gym_manager"
    staff = "staff"
    trainer = "trainer"
    member = "member"
    cashier = "cashier"
    cleaner = "cleaner"

class User(Base):
    """
    Represents a system user (member, staff, trainer, cashier, admin, etc.).
    """
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String)
    gym_id = Column(Integer, ForeignKey("gyms.id"), nullable=True, index=True)
    role = Column(Enum(UserRole), default=UserRole.member, nullable=False)
