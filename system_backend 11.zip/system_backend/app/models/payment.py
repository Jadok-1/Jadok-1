"""
payment.py

SQLAlchemy model for gym payments.
Author: Ndatimana Jean de Dieu
"""

from sqlalchemy import Column, Integer, Float, ForeignKey, Date, String
from app.db.session import Base

class Payment(Base):
    """
    Represents a payment transaction for a gym member.
    """
    __tablename__ = "payments"

    id = Column(Integer, primary_key=True, index=True)
    gym_id = Column(Integer, ForeignKey("gyms.id"), nullable=False, index=True)
    member_id = Column(Integer, ForeignKey("members.id"), nullable=False)
    amount = Column(Float, nullable=False)
    date = Column(Date, nullable=False)
    payment_method = Column(String, nullable=True)
    notes = Column(String, nullable=True)
