"""
gym_membership_plan_template.py

SQLAlchemy model for gym membership plan templates.
Author: Ndatimana Jean de Dieu
"""

from sqlalchemy import Column, Integer, String, Float, ForeignKey
from app.db.session import Base

class GymMembershipPlanTemplate(Base):
    """
    Represents a membership plan template that can be customized per gym.
    """
    __tablename__ = "gym_membership_plan_templates"

    id = Column(Integer, primary_key=True, index=True)
    gym_id = Column(Integer, ForeignKey("gyms.id"), nullable=False, index=True)
    name = Column(String, nullable=False)
    duration_days = Column(Integer, nullable=False)
    price = Column(Float, nullable=False)
    discount_percent = Column(Float, default=0.0)
