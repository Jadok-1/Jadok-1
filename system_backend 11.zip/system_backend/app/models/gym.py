"""
gym.py

SQLAlchemy model for a gym.
Author: Ndatimana Jean de Dieu
"""

from sqlalchemy import Column, Integer, String
from app.db.session import Base

class Gym(Base):
    """
    Represents a gym location or organization.
    """
    __tablename__ = "gyms"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True, nullable=False)
