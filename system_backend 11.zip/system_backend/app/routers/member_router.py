"""
member_router.py

Endpoints for gym member actions (invoices, status, CRUD for workout/nutrition plans, membership renewal, viewing assigned schedules).
Author: Ndatimana Jean de Dieu
"""

from fastapi import APIRouter, Depends, status, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from app.core.rbac import RoleChecker

router = APIRouter(prefix="/member", tags=["Member"])

class PlanScheduleRequest(BaseModel):
    plan_type: str  # "workout" or "nutrition"
    plan_id: int
    start_date: str
    notes: Optional[str] = None

class PlanScheduleUpdate(BaseModel):
    start_date: Optional[str] = None
    notes: Optional[str] = None

class PlanScheduleRead(BaseModel):
    schedule_id: int
    plan_type: str
    plan_id: int
    start_date: str
    notes: Optional[str] = None

    class Config:
        orm_mode = True

class RenewMembershipRequest(BaseModel):
    gym_id: int
    branch_id: int
    membership_plan_id: int

# --- In-memory demo store (replace with DB) ---
scheduled_plans_db: List[PlanScheduleRead] = []

@router.get("/invoices", dependencies=[Depends(RoleChecker(["MEMBER"]))])
def get_invoices():
    """Get all invoices for the current member."""
    return {"msg": "Your invoices"}

@router.post("/renew", dependencies=[Depends(RoleChecker(["MEMBER"]))], status_code=status.HTTP_200_OK)
def renew_membership(request: RenewMembershipRequest):
    """
    Renew membership by selecting gym, branch, and plan.
    """
    return {
        "msg": "Membership renewed",
        "selected_gym_id": request.gym_id,
        "selected_branch_id": request.branch_id,
        "selected_plan_id": request.membership_plan_id
    }

@router.get("/available-gyms", dependencies=[Depends(RoleChecker(["MEMBER"]))])
def available_gyms():
    """Show all available gyms, branches, and membership plans."""
    return {
        "gyms": [
            {
                "gym_id": 1,
                "name": "Downtown Fitness",
                "branches": [
                    {"branch_id": 11, "location": "Kigali Downtown"},
                    {"branch_id": 12, "location": "Kimironko"}
                ],
                "plans": [
                    {"plan_id": 101, "name": "Monthly", "price": 20000},
                    {"plan_id": 102, "name": "Annual", "price": 180000}
                ]
            }
        ]
    }

@router.get("/assigned-schedule", response_model=List[PlanScheduleRead], dependencies=[Depends(RoleChecker(["MEMBER"]))])
def view_assigned_schedule():
    """View all assigned or recommended workout and nutrition schedules for the member."""
    return scheduled_plans_db

# --- CRUD for Member-Created Schedules ---
@router.post("/schedule-plan", response_model=PlanScheduleRead, status_code=status.HTTP_201_CREATED, dependencies=[Depends(RoleChecker(["MEMBER"]))])
def create_schedule_plan(request: PlanScheduleRequest):
    """Create (schedule) a workout or nutrition plan."""
    new_id = (scheduled_plans_db[-1].schedule_id + 1) if scheduled_plans_db else 1
    new_schedule = PlanScheduleRead(
        schedule_id=new_id,
        plan_type=request.plan_type,
        plan_id=request.plan_id,
        start_date=request.start_date,
        notes=request.notes,
    )
    scheduled_plans_db.append(new_schedule)
    return new_schedule

@router.get("/schedule-plans", response_model=List[PlanScheduleRead], dependencies=[Depends(RoleChecker(["MEMBER"]))])
def list_scheduled_plans():
    """View all your scheduled workout/nutrition plans."""
    return scheduled_plans_db

@router.put("/schedule-plan/{schedule_id}", response_model=PlanScheduleRead, dependencies=[Depends(RoleChecker(["MEMBER"]))])
def update_schedule_plan(schedule_id: int, request: PlanScheduleUpdate):
    """Update a scheduled workout/nutrition plan."""
    for schedule in scheduled_plans_db:
        if schedule.schedule_id == schedule_id:
            if request.start_date is not None:
                schedule.start_date = request.start_date
            if request.notes is not None:
                schedule.notes = request.notes
            return schedule
    raise HTTPException(status_code=404, detail="Schedule not found")

@router.delete("/schedule-plan/{schedule_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(RoleChecker(["MEMBER"]))])
def delete_schedule_plan(schedule_id: int):
    """Delete a scheduled workout/nutrition plan."""
    global scheduled_plans_db
    scheduled_plans_db = [s for s in scheduled_plans_db if s.schedule_id != schedule_id]
    return

@router.get("/status", dependencies=[Depends(RoleChecker(["MEMBER"]))])
def membership_status():
    """Check the status of the member's gym membership."""
    return {"msg": "Membership active until 2025-12-01"}
