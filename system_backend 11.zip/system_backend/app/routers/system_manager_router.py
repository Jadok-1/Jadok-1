"""
system_manager_router.py

CRUD endpoints for system manager actions: system plans, gyms, subscriptions, discounts.
Author: Ndatimana Jean de Dieu
"""

from fastapi import APIRouter, Depends, status, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from app.core.rbac import RoleChecker

router = APIRouter(prefix="/system-manager", tags=["System Manager"])

# --- In-memory demo stores (replace with DB logic) ---
system_plans_db = []
gyms_db = []
subscriptions_db = []

# --- Schemas ---
class SystemPlanCreate(BaseModel):
    name: str
    price: float
    duration_days: int

class SystemPlanUpdate(BaseModel):
    name: Optional[str] = None
    price: Optional[float] = None
    duration_days: Optional[int] = None

class SystemPlanRead(SystemPlanCreate):
    id: int

class GymCreate(BaseModel):
    name: str
    owner_name: str

class GymUpdate(BaseModel):
    name: Optional[str] = None
    owner_name: Optional[str] = None

class GymRead(GymCreate):
    id: int

class DiscountApply(BaseModel):
    gym_id: int
    discount_percent: float

class SubscriptionRead(BaseModel):
    id: int
    gym_id: int
    plan_id: int
    status: str

# --- System Plans CRUD ---
@router.get("/system-plans", response_model=List[SystemPlanRead], dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def list_system_plans():
    """List all system-wide subscription plans."""
    return system_plans_db

@router.post("/system-plans", response_model=SystemPlanRead, status_code=status.HTTP_201_CREATED, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def create_system_plan(plan: SystemPlanCreate):
    """Create a new system-wide subscription plan."""
    new_id = (system_plans_db[-1].id + 1) if system_plans_db else 1
    new_plan = SystemPlanRead(id=new_id, **plan.dict())
    system_plans_db.append(new_plan)
    return new_plan

@router.get("/system-plans/{plan_id}", response_model=SystemPlanRead, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def get_system_plan(plan_id: int):
    """Get a system plan by ID."""
    for plan in system_plans_db:
        if plan.id == plan_id:
            return plan
    raise HTTPException(status_code=404, detail="System plan not found")

@router.put("/system-plans/{plan_id}", response_model=SystemPlanRead, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def update_system_plan(plan_id: int, updates: SystemPlanUpdate):
    """Update a system-wide plan."""
    for idx, plan in enumerate(system_plans_db):
        if plan.id == plan_id:
            updated = plan.copy(update=updates.dict(exclude_unset=True))
            system_plans_db[idx] = updated
            return updated
    raise HTTPException(status_code=404, detail="System plan not found")

@router.delete("/system-plans/{plan_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def delete_system_plan(plan_id: int):
    """Delete a system-wide plan."""
    global system_plans_db
    system_plans_db = [p for p in system_plans_db if p.id != plan_id]
    return

# --- Gyms CRUD ---
@router.get("/gyms", response_model=List[GymRead], dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def list_gyms():
    """View all gyms and their branches."""
    return gyms_db

@router.post("/gyms", response_model=GymRead, status_code=status.HTTP_201_CREATED, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def create_gym(gym: GymCreate):
    """Add a new gym and owner."""
    new_id = (gyms_db[-1].id + 1) if gyms_db else 1
    new_gym = GymRead(id=new_id, **gym.dict())
    gyms_db.append(new_gym)
    return new_gym

@router.get("/gyms/{gym_id}", response_model=GymRead, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def get_gym(gym_id: int):
    """Get a gym by ID."""
    for gym in gyms_db:
        if gym.id == gym_id:
            return gym
    raise HTTPException(status_code=404, detail="Gym not found")

@router.put("/gyms/{gym_id}", response_model=GymRead, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def update_gym(gym_id: int, updates: GymUpdate):
    """Update gym details."""
    for idx, gym in enumerate(gyms_db):
        if gym.id == gym_id:
            updated = gym.copy(update=updates.dict(exclude_unset=True))
            gyms_db[idx] = updated
            return updated
    raise HTTPException(status_code=404, detail="Gym not found")

@router.delete("/gyms/{gym_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def delete_gym(gym_id: int):
    """Delete a gym."""
    global gyms_db
    gyms_db = [g for g in gyms_db if g.id != gym_id]
    return

# --- Subscriptions/Discounts ---
@router.get("/subscriptions", response_model=List[SubscriptionRead], dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def list_subscriptions():
    """View all gym system subscriptions."""
    return subscriptions_db

@router.post("/discount", dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))], status_code=status.HTTP_200_OK)
def apply_discount(request: DiscountApply):
    """Apply a discount to a specific gym's subscription."""
    # Implement actual DB logic here
    return {"msg": f"Discount of {request.discount_percent}% applied to gym {request.gym_id}"}
"""
system_manager_router.py

CRUD endpoints for system manager: SaaS system subscription plans.
Author: Ndatimana Jean de Dieu
"""

from fastapi import APIRouter, Depends, status, HTTPException
from typing import List
from app.core.rbac import RoleChecker
from schemas.system_subscription_plan import (
    SystemSubscriptionPlanCreate,
    SystemSubscriptionPlanUpdate,
    SystemSubscriptionPlanRead,
)

router = APIRouter(prefix="/system-manager", tags=["System Manager"])

# --- In-memory DB for demo (replace with real DB queries) ---
system_plans_db = []

@router.get("/system-plans", response_model=List[SystemSubscriptionPlanRead], dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def list_system_plans():
    """List all SaaS system subscription plans."""
    return system_plans_db

@router.post("/system-plans", response_model=SystemSubscriptionPlanRead, status_code=status.HTTP_201_CREATED, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def create_system_plan(plan: SystemSubscriptionPlanCreate):
    """Create a new SaaS system subscription plan."""
    new_id = (system_plans_db[-1].id + 1) if system_plans_db else 1
    new_plan = SystemSubscriptionPlanRead(id=new_id, **plan.dict())
    system_plans_db.append(new_plan)
    return new_plan

@router.get("/system-plans/{plan_id}", response_model=SystemSubscriptionPlanRead, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def get_system_plan(plan_id: int):
    """Get a SaaS system subscription plan by ID."""
    for plan in system_plans_db:
        if plan.id == plan_id:
            return plan
    raise HTTPException(status_code=404, detail="System plan not found")

@router.put("/system-plans/{plan_id}", response_model=SystemSubscriptionPlanRead, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def update_system_plan(plan_id: int, updates: SystemSubscriptionPlanUpdate):
    """Update a SaaS system subscription plan."""
    for idx, plan in enumerate(system_plans_db):
        if plan.id == plan_id:
            updated = plan.copy(update=updates.dict(exclude_unset=True))
            system_plans_db[idx] = updated
            return updated
    raise HTTPException(status_code=404, detail="System plan not found")

@router.delete("/system-plans/{plan_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def delete_system_plan(plan_id: int):
    """Delete a SaaS system subscription plan."""
    global system_plans_db
    system_plans_db = [p for p in system_plans_db if p.id != plan_id]
    return
