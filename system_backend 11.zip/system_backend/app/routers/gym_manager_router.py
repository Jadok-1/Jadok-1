"""
gym_manager_router.py

CRUD endpoints for gym manager actions: membership plans, staff (trainer/cashier/cleaner), and expenses.
Author: Ndatimana Jean de Dieu
"""

from fastapi import APIRouter, Depends, status, HTTPException
from pydantic import BaseModel, EmailStr
from typing import List, Optional
from app.core.rbac import RoleChecker

router = APIRouter(prefix="/gym-manager", tags=["Gym Manager"])

# --- In-memory demo stores (replace with DB logic) ---
membership_plans_db = []
staff_db = []
expenses_db = []

# --- Schemas ---
class MembershipPlanCreate(BaseModel):
    name: str
    price: float

class MembershipPlanUpdate(BaseModel):
    name: Optional[str] = None
    price: Optional[float] = None

class MembershipPlanRead(MembershipPlanCreate):
    id: int

class StaffCreateRequest(BaseModel):
    email: EmailStr
    password: str
    full_name: str
    role: str  # Should be validated: 'cashier', 'trainer', 'cleaner'

class StaffUpdateRequest(BaseModel):
    email: Optional[EmailStr] = None
    full_name: Optional[str] = None
    role: Optional[str] = None

class StaffRead(BaseModel):
    id: int
    email: EmailStr
    full_name: str
    role: str

class ExpenseCreate(BaseModel):
    title: str
    amount: float

class ExpenseUpdate(BaseModel):
    title: Optional[str] = None
    amount: Optional[float] = None

class ExpenseRead(ExpenseCreate):
    id: int

# --- Membership Plans CRUD ---

@router.get("/membership-plans", response_model=List[MembershipPlanRead], dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def list_membership_plans():
    """List all membership plans."""
    return membership_plans_db

@router.post("/membership-plans", response_model=MembershipPlanRead, status_code=status.HTTP_201_CREATED, dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def create_membership_plan(plan: MembershipPlanCreate):
    """Create a new membership plan."""
    new_id = (membership_plans_db[-1].id + 1) if membership_plans_db else 1
    new_plan = MembershipPlanRead(id=new_id, **plan.dict())
    membership_plans_db.append(new_plan)
    return new_plan

@router.get("/membership-plans/{plan_id}", response_model=MembershipPlanRead, dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def get_membership_plan(plan_id: int):
    """Get a membership plan by ID."""
    for plan in membership_plans_db:
        if plan.id == plan_id:
            return plan
    raise HTTPException(status_code=404, detail="Membership plan not found")

@router.put("/membership-plans/{plan_id}", response_model=MembershipPlanRead, dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def update_membership_plan(plan_id: int, updates: MembershipPlanUpdate):
    """Update a membership plan."""
    for idx, plan in enumerate(membership_plans_db):
        if plan.id == plan_id:
            updated = plan.copy(update=updates.dict(exclude_unset=True))
            membership_plans_db[idx] = updated
            return updated
    raise HTTPException(status_code=404, detail="Membership plan not found")

@router.delete("/membership-plans/{plan_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def delete_membership_plan(plan_id: int):
    """Delete a membership plan."""
    global membership_plans_db
    membership_plans_db = [plan for plan in membership_plans_db if plan.id != plan_id]
    return

# --- Staff CRUD ---

@router.get("/staff", response_model=List[StaffRead], dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def list_staff():
    """List all staff (trainer/cashier/cleaner)."""
    return staff_db

@router.post("/staff", response_model=StaffRead, status_code=status.HTTP_201_CREATED, dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def create_staff(request: StaffCreateRequest):
    """Add a new staff member (trainer/cashier/cleaner)."""
    new_id = (staff_db[-1].id + 1) if staff_db else 1
    new_staff = StaffRead(id=new_id, email=request.email, full_name=request.full_name, role=request.role)
    staff_db.append(new_staff)
    return new_staff

@router.get("/staff/{staff_id}", response_model=StaffRead, dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def get_staff(staff_id: int):
    """Get a staff member by ID."""
    for staff in staff_db:
        if staff.id == staff_id:
            return staff
    raise HTTPException(status_code=404, detail="Staff not found")

@router.put("/staff/{staff_id}", response_model=StaffRead, dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def update_staff(staff_id: int, updates: StaffUpdateRequest):
    """Update staff info."""
    for idx, staff in enumerate(staff_db):
        if staff.id == staff_id:
            updated = staff.copy(update=updates.dict(exclude_unset=True))
            staff_db[idx] = updated
            return updated
    raise HTTPException(status_code=404, detail="Staff not found")

@router.delete("/staff/{staff_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def delete_staff(staff_id: int):
    """Delete a staff member."""
    global staff_db
    staff_db = [s for s in staff_db if s.id != staff_id]
    return

# --- Expense CRUD ---

@router.get("/expenses", response_model=List[ExpenseRead], dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def list_expenses():
    """List all expenses."""
    return expenses_db

@router.post("/expenses", response_model=ExpenseRead, status_code=status.HTTP_201_CREATED, dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def create_expense(expense: ExpenseCreate):
    """Create a new expense."""
    new_id = (expenses_db[-1].id + 1) if expenses_db else 1
    new_exp = ExpenseRead(id=new_id, **expense.dict())
    expenses_db.append(new_exp)
    return new_exp

@router.get("/expenses/{expense_id}", response_model=ExpenseRead, dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def get_expense(expense_id: int):
    """Get an expense by ID."""
    for exp in expenses_db:
        if exp.id == expense_id:
            return exp
    raise HTTPException(status_code=404, detail="Expense not found")

@router.put("/expenses/{expense_id}", response_model=ExpenseRead, dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def update_expense(expense_id: int, updates: ExpenseUpdate):
    """Update an expense."""
    for idx, exp in enumerate(expenses_db):
        if exp.id == expense_id:
            updated = exp.copy(update=updates.dict(exclude_unset=True))
            expenses_db[idx] = updated
            return updated
    raise HTTPException(status_code=404, detail="Expense not found")

@router.delete("/expenses/{expense_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def delete_expense(expense_id: int):
    """Delete an expense."""
    global expenses_db
    expenses_db = [e for e in expenses_db if e.id != expense_id]
    return
