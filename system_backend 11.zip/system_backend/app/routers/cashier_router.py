"""
cashier_router.py

Endpoints for cashier-specific actions (invoicing, payments, reports, attendance).
Author: Ndatimana Jean de Dieu
"""

from fastapi import APIRouter, Depends, status
from app.core.rbac import RoleChecker

router = APIRouter(prefix="/cashier", tags=["Cashier"])

# --- Members ---
@router.post("/add-member", dependencies=[Depends(RoleChecker(["CASHIER"]))], status_code=status.HTTP_201_CREATED)
def add_member(name: str):
    """Add a new member to the gym."""
    return {"msg": f"Member '{name}' added"}

@router.get("/members", dependencies=[Depends(RoleChecker(["CASHIER"]))])
def view_members():
    """List all active and expired members."""
    return {"msg": "List of active and expired members"}

# --- Invoices and Payments ---
@router.post("/invoice", dependencies=[Depends(RoleChecker(["CASHIER"]))], status_code=status.HTTP_201_CREATED)
def create_invoice(member_id: int, amount: float):
    """Create a new invoice for a member."""
    return {"msg": f"Invoice created for member {member_id} - Amount: {amount}"}

@router.put("/invoice/{invoice_id}", dependencies=[Depends(RoleChecker(["CASHIER"]))])
def edit_invoice(invoice_id: int, amount: float):
    """Edit an existing invoice."""
    return {"msg": f"Invoice {invoice_id} updated to amount {amount}"}

@router.delete("/invoice/{invoice_id}", dependencies=[Depends(RoleChecker(["CASHIER"]))], status_code=status.HTTP_204_NO_CONTENT)
def delete_invoice(invoice_id: int, reason: str):
    """Delete an invoice with a reason."""
    return {"msg": f"Invoice {invoice_id} deleted. Reason: {reason}"}

@router.get("/invoices", dependencies=[Depends(RoleChecker(["CASHIER"]))])
def view_all_invoices():
    """List all invoices."""
    return {"msg": "All invoices listed"}

# --- Payments ---
@router.post("/payment", dependencies=[Depends(RoleChecker(["CASHIER"]))], status_code=status.HTTP_201_CREATED)
def record_payment(member_id: int, amount: float, method: str):
    """Record a payment for a member."""
    return {"msg": f"Payment of {amount} by member {member_id} recorded via {method}"}

@router.get("/payments", dependencies=[Depends(RoleChecker(["CASHIER"]))])
def list_payments():
    """List all payments."""
    return {"msg": "List of all payments"}

# --- Reports ---
@router.get("/financial-report", dependencies=[Depends(RoleChecker(["CASHIER"]))])
def view_financial_report(branch_id: int):
    """View the financial report for a branch."""
    return {"msg": f"Financial report for branch {branch_id}"}

@router.get("/attendance-report", dependencies=[Depends(RoleChecker(["CASHIER"]))])
def view_member_attendance():
    """Get attendance report of members."""
    return {"msg": "Attendance report of members"}

# --- Staff Attendance Reports ---
@router.post("/report-staff-attendance", dependencies=[Depends(RoleChecker(["CASHIER"]))], status_code=status.HTTP_201_CREATED)
def report_staff_attendance(staff_id: int, role: str):
    """Report attendance for a staff member by role."""
    return {"msg": f"Attendance reported for {role} ID {staff_id}"}

@router.get("/staff-attendance", dependencies=[Depends(RoleChecker(["CASHIER"]))])
def view_staff_attendance():
    """Get trainer and cleaner attendance list."""
    return {"msg": "Trainer and Cleaner attendance list"}
