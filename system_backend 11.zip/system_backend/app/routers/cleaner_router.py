"""
cleaner_router.py

Endpoints for gym cleaners (view work schedules only).
Author: Ndatimana Jean de Dieu
"""

from fastapi import APIRouter, Depends
from app.core.rbac import RoleChecker

router = APIRouter(prefix="/cleaner", tags=["Cleaner"])

@router.get("/schedule", dependencies=[Depends(RoleChecker(["CLEANER"]))])
def get_cleaner_schedule():
    """View the cleaner's work schedule."""
    return {"msg": "Your work schedule"}
