from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# Fake method to get user info from token (replace with your JWT decoder or auth method)
def get_current_user(token: str = Depends(oauth2_scheme)):
    # Example hardcoded roles (you'll replace this with real decoding)
    fake_users = {
        "member_token": {"username": "member1", "role": "MEMBER"},
        "trainer_token": {"username": "trainer1", "role": "TRAINER"},
        "cashier_token": {"username": "cashier1", "role": "CASHIER"},
        "manager_token": {"username": "manager1", "role": "MANAGER"},
        "owner_token": {"username": "owner1", "role": "OWNER"},
        "system_token": {"username": "sysadmin", "role": "SYSTEM_MANAGER"},
        "cleaner_token": {"username": "cleaner1", "role": "CLEANER"},
    }
    user = fake_users.get(token)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid authentication")
    return user

class RoleChecker:
    def __init__(self, allowed_roles: list[str]):
        self.allowed_roles = allowed_roles

    def __call__(self, user=Depends(get_current_user)):
        if user["role"] not in self.allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Operation not permitted"
            )
        return user
