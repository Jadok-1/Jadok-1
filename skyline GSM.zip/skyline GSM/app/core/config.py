from pydantic import BaseSettings

class Settings(BaseSettings):
    PROJECT_NAME: str = "Smart Gym System"
    DATABASE_URL: str = "postgresql://user:password@localhost/gymdb"
    JWT_SECRET_KEY: str = "supersecretkey"
    EMAIL_SENDER: str = "your@email.com"
    WHATSAPP_API_URL: str = "https://api.whatsapp.com/send"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    ALGORITHM: str = "HS256"

    class Config:
        env_file = ".env"
        case_sensitive = True

settings = Settings()
