from datetime import date, timedelta
from app.core.config import settings
from sqlalchemy.orm import Session
from app.crud import client as crud_client

def send_membership_expiry_notification(db: Session, client_id: int, membership_end_date: date, days_left: int):
    client = crud_client.get_client(db, client_id=client_id)
    if not client:
        print(f"Notification failed: Client ID {client_id} not found.")
        return

    contact_info = client.email or client.phone_number
    contact_type = 'email' if client.email else ('whatsapp' if client.phone_number else None)
    client_name = client.name

    if not contact_info or not contact_type:
        print(f"Notification failed: No contact info for client {client_name} (ID: {client_id})")
        return

    subject = f"Your Membership at [Gym Name] is Expiring Soon!"
    body = f"""
    Hi {client_name},

    This is a friendly reminder that your membership at [Gym Name] is expiring on {membership_end_date.strftime('%Y-%m-%d')}.
    You have {days_left} days left.

    Please visit the gym or log in to your account to renew your membership and continue enjoying our facilities!

    Best regards,
    The [Gym Name] Team
    """

    print(f"--- Notification Triggered ---")
    print(f"Attempting to send '{contact_type}' expiry notification for {client_name} (ID: {client_id})")
    print(f"Membership ends on: {membership_end_date}")
    print(f"To: {contact_info}")
    print(f"--- End Notification Triggered ---")

def send_email(recipient: str, subject: str, body: str):
    print(f"[EMAIL PLACEHOLDER] Sending email to {recipient} with subject '{subject}'")

def send_whatsapp_message(phone_number: str, message: str):
    print(f"[WHATSAPP PLACEHOLDER] Sending WhatsApp message to {phone_number}")
