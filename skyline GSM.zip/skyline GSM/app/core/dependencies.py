from typing import Generator
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer
from sqlalchemy.orm import Session
from datetime import datetime
from app.db.session import SessionLocal
from app.models.user import User, UserRole
from app.models.client import Client
from app.core import security

def get_db() -> Generator:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

oauth2_scheme = HTTPBearer()

def get_current_user(db: Session = Depends(get_db), token_obj = Depends(oauth2_scheme)) -> User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    token = token_obj.credentials
    token_data = security.verify_token(token)
    if token_data is None:
        raise credentials_exception
    email: str = token_data.get("sub")
    if email is None:
        raise credentials_exception
    user = db.query(User).filter(User.email == email).first()
    if user is None:
        raise credentials_exception
    return user

def get_current_active_user_in_gym(current_user: User = Depends(get_current_user)) -> User:
    if current_user.gym_id is None or current_user.role == UserRole.system_manager:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User does not belong to a gym or is a System Manager (global user)",
        )
    return current_user

def get_system_manager(current_user: User = Depends(get_current_user)) -> User:
    if current_user.role != UserRole.system_manager:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized: Requires System Manager role",
        )
    return current_user

def get_gym_owner(current_user: User = Depends(get_current_active_user_in_gym)) -> User:
    if current_user.role != UserRole.gym_owner:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized: Requires Gym Owner role",
        )
    return current_user

def get_staff(current_user: User = Depends(get_current_active_user_in_gym)) -> User:
    if current_user.role != UserRole.staff:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized: Requires Staff role",
        )
    return current_user

def get_trainer(current_user: User = Depends(get_current_active_user_in_gym)) -> User:
    if current_user.role != UserRole.trainer:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized: Requires Trainer role",
        )
    return current_user

def get_client_user(current_user: User = Depends(get_current_active_user_in_gym)) -> User:
    if current_user.role != UserRole.client:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized: Requires Client role",
        )
    return current_user

def get_current_client_profile(db: Session = Depends(get_db), client_user: User = Depends(get_client_user)) -> Client:
    client_profile = db.query(Client).filter(Client.user_id == client_user.id, Client.gym_id == client_user.gym_id).first()
    if not client_profile:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Client profile not found for this user. Data inconsistency."
        )
    return client_profile

def get_owner_or_staff(current_user: User = Depends(get_current_active_user_in_gym)) -> User:
    if current_user.role not in [UserRole.gym_owner, UserRole.staff]:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized: Requires Owner or Staff role")
    return current_user

def get_owner_staff_or_trainer(current_user: User = Depends(get_current_active_user_in_gym)) -> User:
    if current_user.role not in [UserRole.gym_owner, UserRole.staff, UserRole.trainer]:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized: Requires Owner, Staff, or Trainer role")
    return current_user
