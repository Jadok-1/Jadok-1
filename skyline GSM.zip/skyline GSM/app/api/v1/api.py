from fastapi import APIRouter

# Original routers
from app.api.v1.endpoints import (
    auth, users, gyms, clients, payments, memberships,
    workout_plans, nutrition_plans, gym_membership_plans,
    attendance, equipment, system
)

# Role-based routers
from app.routers import (
    member_router,
    trainer_router,
    cleaner_router,
    cashier_router,
    gym_manager_router,
    gym_owner_router,
    system_manager_router
)

api_router = APIRouter()

# Include original routers
api_router.include_router(auth.auth_router)
api_router.include_router(users.user_router)
api_router.include_router(gyms.gym_router)
api_router.include_router(clients.client_router)
api_router.include_router(payments.payment_router)
api_router.include_router(memberships.membership_router)
api_router.include_router(workout_plans.workout_router)
api_router.include_router(nutrition_plans.nutrition_router)
api_router.include_router(gym_membership_plans.gym_membership_plan_router)
api_router.include_router(attendance.attendance_router)
api_router.include_router(equipment.equipment_router)
api_router.include_router(system.system_router)

# Include role-based routers
api_router.include_router(member_router.router, prefix="/member", tags=["Member"])
api_router.include_router(trainer_router.router, prefix="/trainer", tags=["Trainer"])
api_router.include_router(cleaner_router.router, prefix="/cleaner", tags=["Cleaner"])
api_router.include_router(cashier_router.router, prefix="/cashier", tags=["Cashier"])
api_router.include_router(gym_manager_router.router, prefix="/gym-manager", tags=["Gym Manager"])
api_router.include_router(gym_owner_router.router, prefix="/gym-owner", tags=["Gym Owner"])
api_router.include_router(system_manager_router.router, prefix="/system-manager", tags=["System Manager"])
