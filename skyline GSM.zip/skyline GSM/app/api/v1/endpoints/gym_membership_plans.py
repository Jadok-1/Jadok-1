from fastapi import APIRouter

gym_membership_plans_router = APIRouter()
