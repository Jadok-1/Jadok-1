from fastapi import APIRouter

users_router = APIRouter()
