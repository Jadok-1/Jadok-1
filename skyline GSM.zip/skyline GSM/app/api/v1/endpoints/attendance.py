from fastapi import APIRouter

attendance_router = APIRouter()
