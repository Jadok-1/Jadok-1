from fastapi import APIRouter

equipment_router = APIRouter()
