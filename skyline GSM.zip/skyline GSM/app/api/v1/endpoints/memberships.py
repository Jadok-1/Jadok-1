from fastapi import APIRouter

memberships_router = APIRouter()
