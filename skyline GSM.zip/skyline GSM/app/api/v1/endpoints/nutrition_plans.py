from fastapi import APIRouter

nutrition_plans_router = APIRouter()
