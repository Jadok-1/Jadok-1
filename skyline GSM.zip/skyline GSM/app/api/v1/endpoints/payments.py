from fastapi import APIRouter

payments_router = APIRouter()
