from fastapi import APIRouter

workout_plans_router = APIRouter()
