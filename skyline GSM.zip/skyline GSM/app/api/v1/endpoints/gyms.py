from fastapi import APIRouter

gyms_router = APIRouter()
