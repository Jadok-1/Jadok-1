from fastapi import APIRouter

system_router = APIRouter()
