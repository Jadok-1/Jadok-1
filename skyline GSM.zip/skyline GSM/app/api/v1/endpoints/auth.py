from fastapi import APIRouter

auth_router = APIRouter()
