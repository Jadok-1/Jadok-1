from pydantic import BaseModel, EmailStr
from typing import Optional
from app.models.user import UserRole

class UserCreateInternal(BaseModel):
    email: EmailStr
    password: str
    full_name: Optional[str] = None
    role: UserRole
    gym_id: Optional[int] = None

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    full_name: Optional[str] = None

class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    full_name: Optional[str] = None
    password: Optional[str] = None

class UserRead(BaseModel):
    id: int
    email: EmailStr
    full_name: Optional[str] = None
    role: UserRole
    gym_id: Optional[int] = None

    class Config:
        orm_mode = True
        use_enum_values = True
