from pydantic import BaseModel

class GymMembershipPlanTemplateBase(BaseModel):
    name: str
    duration_days: int

class GymMembershipPlanTemplateCreate(GymMembershipPlanTemplateBase):
    pass

class GymMembershipPlanTemplateUpdate(BaseModel):
    name: Optional[str] = None
    duration_days: Optional[int] = None
    price: Optional[float] = None
    discount_percent: Optional[float] = None

class GymMembershipPlanTemplateRead(GymMembershipPlanTemplateBase):
    id: int
    gym_id: int

    class Config:
        orm_mode = True
