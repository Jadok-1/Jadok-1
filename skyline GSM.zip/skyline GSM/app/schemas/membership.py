from pydantic import BaseModel
from datetime import date
from typing import Optional

class MembershipBase(BaseModel):
    client_id: int
    membership_type: str
    price: float
    discount_percent: float = 0.0
    start_date: date
    end_date: date

class MembershipCreate(MembershipBase):
    pass

class MembershipUpdate(BaseModel):
    client_id: Optional[int] = None
    membership_type: Optional[str] = None
    price: Optional[float] = None
    discount_percent: Optional[float] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None

class MembershipRead(MembershipBase):
    id: int
    gym_id: int
    creator_user_id: int

    class Config:
        orm_mode = True
