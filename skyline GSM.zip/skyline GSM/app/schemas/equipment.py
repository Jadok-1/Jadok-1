from pydantic import BaseModel
from typing import Optional
from app.models.equipment import EquipmentStatus

class EquipmentBase(BaseModel):
    name: str
    description: Optional[str] = None
    status: EquipmentStatus

class EquipmentCreate(EquipmentBase):
    pass

class EquipmentUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[EquipmentStatus] = None

class EquipmentRead(EquipmentBase):
    id: int
    gym_id: int

    class Config:
        orm_mode = True
        use_enum_values = True
