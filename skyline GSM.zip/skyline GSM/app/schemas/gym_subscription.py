from pydantic import BaseModel
from datetime import date
from typing import Optional
from app.models.gym_subscription import SubscriptionStatus

class GymSubscriptionBase(BaseModel):
    gym_id: int
    plan_name: str
    monthly_price: float
    start_date: date
    end_date: Optional[date] = None
    status: SubscriptionStatus
    last_payment_date: Optional[date] = None

class GymSubscriptionCreate(GymSubscriptionBase):
    pass

class GymSubscriptionUpdate(BaseModel):
    plan_name: Optional[str] = None
    monthly_price: Optional[float] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    status: Optional[SubscriptionStatus] = None
    last_payment_date: Optional[date] = None

class GymSubscriptionRead(GymSubscriptionBase):
    id: int

    class Config:
        orm_mode = True
        use_enum_values = True
