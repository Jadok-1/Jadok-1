from pydantic import BaseModel
from datetime import date
from app.models.equipment_issue import EquipmentIssue
from typing import Optional

class EquipmentIssueBase(BaseModel):
    equipment_id: int
    reported_date: date
    description: str

class EquipmentIssueCreate(EquipmentIssueBase):
    pass

class EquipmentIssueUpdate(BaseModel):
    equipment_id: Optional[int] = None
    reported_date: Optional[date] = None
    description: Optional[str] = None

class EquipmentIssueRead(EquipmentIssueBase):
    id: int
    gym_id: int
    reported_by_user_id: int

    class Config:
        orm_mode = True
