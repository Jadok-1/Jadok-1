from pydantic import BaseModel
from datetime import date
from typing import Optional

class NutritionPlanBase(BaseModel):
    client_id: int
    title: str
    description: Optional[str] = None
    assigned_date: date

class NutritionPlanCreate(NutritionPlanBase):
    pass

class NutritionPlanUpdate(BaseModel):
    client_id: Optional[int] = None
    title: Optional[str] = None
    description: Optional[str] = None
    assigned_date: Optional[date] = None

class NutritionPlanRead(NutritionPlanBase):
    id: int
    gym_id: int
    trainer_user_id: int

    class Config:
        orm_mode = True
