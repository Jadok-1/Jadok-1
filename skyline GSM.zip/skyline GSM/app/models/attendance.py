import enum
from sqlalchemy import Column, Integer, Enum, ForeignKey, Date, DateTime
from app.db.session import Base

class AttendanceType(str, enum.Enum):
    member = "member"
    staff = "staff"
    trainer = "trainer"
    cleaner = "cleaner"

class Attendance(Base):
    __tablename__ = "attendance"

    id = Column(Integer, primary_key=True, index=True)
    gym_id = Column(Integer, ForeignKey("gyms.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    client_id = Column(Integer, ForeignKey("clients.id"), nullable=True)
    attendance_type = Column(Enum(AttendanceType), nullable=False)
    date = Column(Date, nullable=False)
    timestamp = Column(DateTime, nullable=True)
