import enum
from sqlalchemy import Column, Integer, String, ForeignKey, Date, Float, Enum
from app.db.session import Base

class SubscriptionStatus(str, enum.Enum):
    trial = "trial"
    active = "active"
    lapsed = "lapsed"
    cancelled = "cancelled"
    expired = "expired"

class GymSubscription(Base):
    __tablename__ = "gym_subscriptions"

    id = Column(Integer, primary_key=True, index=True)
    gym_id = Column(Integer, ForeignKey("gyms.id"), unique=True, nullable=False)
    plan_name = Column(String, nullable=False)
    monthly_price = Column(Float, nullable=False)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=True)
    status = Column(Enum(SubscriptionStatus), default=SubscriptionStatus.trial, nullable=False)
    last_payment_date = Column(Date, nullable=True)
