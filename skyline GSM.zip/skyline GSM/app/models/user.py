import enum
from sqlalchemy import Column, Integer, String, ForeignKey, Enum
from sqlalchemy.orm import relationship
from app.db.session import Base

class UserRole(str, enum.Enum):
    system_manager = "system_manager"
    gym_owner = "gym_owner"
    staff = "staff"
    trainer = "trainer"
    client = "client"

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String)
    gym_id = Column(Integer, ForeignKey("gyms.id"), nullable=True, index=True)
    role = Column(Enum(UserRole), default=UserRole.client, nullable=False)
