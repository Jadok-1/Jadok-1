import enum
from sqlalchemy import Column, Integer, String, ForeignKey, Text, Enum
from app.db.session import Base

class EquipmentStatus(str, enum.Enum):
    operational = "operational"
    needs_maintenance = "needs_maintenance"
    defected = "defected"
    out_of_service = "out_of_service"

class Equipment(Base):
    __tablename__ = "equipment"

    id = Column(Integer, primary_key=True, index=True)
    gym_id = Column(Integer, ForeignKey("gyms.id"), nullable=False, index=True)
    name = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    status = Column(Enum(EquipmentStatus), default=EquipmentStatus.operational, nullable=False)
