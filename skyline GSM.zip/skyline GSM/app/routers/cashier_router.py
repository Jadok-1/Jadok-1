from fastapi import APIRouter, Depends
from app.core.rbac import RoleChecker

router = APIRouter(prefix="/cashier", tags=["Cashier"])

# Invoices and Payments
@router.post("/invoice", dependencies=[Depends(RoleChecker(["CASHIER"]))])
def create_invoice(member_id: int, amount: float):
    return {"msg": f"Invoice created for member {member_id} - Amount: {amount}"}

@router.put("/invoice/{invoice_id}", dependencies=[Depends(RoleChecker(["CASHIER"]))])
def edit_invoice(invoice_id: int):
    return {"msg": f"Invoice {invoice_id} edited"}

@router.delete("/invoice/{invoice_id}", dependencies=[Depends(RoleChecker(["CASHIER"]))])
def delete_invoice(invoice_id: int, reason: str):
    return {"msg": f"Invoice {invoice_id} deleted. Reason: {reason}"}

@router.get("/invoices", dependencies=[Depends(RoleChecker(["CASHIER"]))])
def view_all_invoices():
    return {"msg": "All invoices listed"}

# Reports
@router.get("/financial-report", dependencies=[Depends(RoleChecker(["CASHIER"]))])
def view_financial_report(branch_id: int):
    return {"msg": f"Financial report for branch {branch_id}"}

@router.get("/attendance-report", dependencies=[Depends(RoleChecker(["CASHIER"]))])
def view_member_attendance():
    return {"msg": "Attendance report of members"}

@router.get("/members", dependencies=[Depends(RoleChecker(["CASHIER"]))])
def view_members():
    return {"msg": "List of active and expired members"}

# Members
@router.post("/add-member", dependencies=[Depends(RoleChecker(["CASHIER"]))])
def add_member(name: str):
    return {"msg": f"Member {name} added"}

# Staff Attendance Reports
@router.post("/report-staff-attendance", dependencies=[Depends(RoleChecker(["CASHIER"]))])
def report_staff_attendance(staff_id: int, role: str):
    return {"msg": f"Attendance reported for {role} ID {staff_id}"}

@router.get("/staff-attendance", dependencies=[Depends(RoleChecker(["CASHIER"]))])
def view_staff_attendance():
    return {"msg": "Trainer and Cleaner attendance list"}
