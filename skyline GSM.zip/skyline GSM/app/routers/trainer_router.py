from fastapi import APIRouter, Depends
from app.core.rbac import RoleChecker

router = APIRouter(prefix="/trainer", tags=["Trainer"])

@router.get("/schedule", dependencies=[Depends(RoleChecker(["TRAINER"]))])
def get_trainer_schedule():
    return {"msg": "Your gym work schedule"}

@router.post("/assign-workout", dependencies=[Depends(RoleChecker(["TRAINER"]))])
def assign_workout(member_id: int):
    return {"msg": f"Workout schedule assigned to member {member_id}"}

@router.post("/assign-nutrition", dependencies=[Depends(RoleChecker(["TRAINER"]))])
def assign_nutrition(member_id: int):
    return {"msg": f"Nutrition plan assigned to member {member_id}"}

@router.post("/report-equipment", dependencies=[Depends(RoleChecker(["TRAINER"]))])
def report_equipment(equipment_id: int, issue: str):
    return {"msg": f"Issue reported for equipment {equipment_id}: {issue}"}
