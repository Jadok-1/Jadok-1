from fastapi import APIRouter, Depends
from app.core.rbac import RoleChecker

router = APIRouter(prefix="/gym-owner", tags=["Gym Owner"])

@router.get("/income-statements", dependencies=[Depends(RoleChecker(["GYM_OWNER"]))])
def view_all_branch_income():
    return {"msg": "Income statements for all branches"}

@router.get("/subscription-status", dependencies=[Depends(RoleChecker(["GYM_OWNER"]))])
def view_system_subscription():
    return {"msg": "System (software) subscription status"}

@router.post("/add-branch", dependencies=[Depends(RoleChecker(["GYM_OWNER"]))])
def add_gym_branch(name: str, location: str):
    return {"msg": f"Branch '{name}' at '{location}' added"}

@router.post("/add-gym-manager", dependencies=[Depends(RoleChecker(["GYM_OWNER"]))])
def add_gym_manager(name: str):
    return {"msg": f"Gym Manager '{name}' added"}
