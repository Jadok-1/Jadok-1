from fastapi import APIRouter, Depends
from app.core.rbac import RoleChecker

router = APIRouter(prefix="/cleaner", tags=["Cleaner"])

@router.get("/schedule", dependencies=[Depends(RoleChecker(["CLEANER"]))])
def view_cleaning_schedule():
    return {"msg": "Your cleaning schedule"}

@router.get("/notifications", dependencies=[Depends(RoleChecker(["CLEANER"]))])
def view_notifications():
    return {"msg": "Notifications about cleaning tasks"}
