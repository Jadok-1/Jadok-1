from fastapi import APIRouter, Depends
from app.core.rbac import RoleChecker

router = APIRouter(prefix="/system-manager", tags=["System Manager"])

@router.post("/subscription-plan", dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def create_subscription_plan(name: str, price: float, duration_days: int):
    return {"msg": f"Subscription plan '{name}' created: {price} for {duration_days} days"}

@router.get("/gyms", dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def view_all_gyms():
    return {"msg": "List of all gyms and their branches"}

@router.post("/add-gym", dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def add_new_gym(name: str, owner_name: str):
    return {"msg": f"Gym '{name}' added with owner '{owner_name}'"}

@router.get("/subscriptions", dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def view_all_subscriptions():
    return {"msg": "All gyms’ system subscription statuses"}

@router.post("/discount", dependencies=[Depends(RoleChecker(["SYSTEM_MANAGER"]))])
def apply_discount(gym_id: int, discount_percent: float):
    return {"msg": f"Discount of {discount_percent}% applied to gym {gym_id}"}
