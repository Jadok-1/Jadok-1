from fastapi import APIRouter, Depends
from app.core.rbac import RoleChecker

router = APIRouter(prefix="/gym-manager", tags=["Gym Manager"])

@router.get("/financial-reports", dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def view_branch_reports(branch_id: int):
    return {"msg": f"Financial report for branch {branch_id}"}

@router.post("/membership-plan", dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def add_membership_plan(name: str, price: float):
    return {"msg": f"Plan '{name}' added with price {price}"}

@router.put("/membership-plan/{plan_id}", dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def edit_membership_plan(plan_id: int, price: float):
    return {"msg": f"Plan {plan_id} updated with new price {price}"}

@router.post("/add-staff", dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def add_staff(name: str, role: str):
    return {"msg": f"{role} {name} added"}

@router.delete("/delete-staff/{staff_id}", dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def delete_staff(staff_id: int):
    return {"msg": f"Staff with ID {staff_id} deleted"}

@router.post("/expense", dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def input_expense(title: str, amount: float):
    return {"msg": f"Expense '{title}' of {amount} added"}

@router.get("/income-statement", dependencies=[Depends(RoleChecker(["GYM_MANAGER"]))])
def view_income_statement():
    return {"msg": "Income statement for your branch"}
