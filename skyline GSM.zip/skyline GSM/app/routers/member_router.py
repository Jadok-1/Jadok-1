from fastapi import APIRouter, Depends
from app.core.rbac import RoleChecker

router = APIRouter(prefix="/member", tags=["Member"])

@router.get("/invoices", dependencies=[Depends(RoleChecker(["MEMBER"]))])
def get_invoices():
    return {"msg": "Your invoices"}

@router.post("/renew", dependencies=[Depends(RoleChecker(["MEMBER"]))])
def renew_membership():
    return {"msg": "Membership renewed"}

@router.get("/schedule", dependencies=[Depends(RoleChecker(["MEMBER"]))])
def view_schedule():
    return {"msg": "Workout & Nutrition Schedule"}

@router.get("/status", dependencies=[Depends(RoleChecker(["MEMBER"]))])
def membership_status():
    return {"msg": "Membership active until 2025-12-01"}
